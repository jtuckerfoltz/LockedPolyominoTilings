import LockedHeptomino.Generated.EnumerationData
import LockedHeptomino.Isometry
import LockedHeptomino.DigitEncoding

namespace LockedHeptomino.Encoding

def typeCells (index : Nat) : List Cell := (Generated.level6.lookup index).cells

def orientedCells (orientation index : Nat) : List Cell :=
  (typeCells index).map (dihedralIso orientation).equiv

def rootIndex (p : Cell) : Nat := (p.1 + 7).toNat * 16 + (p.2 + 7).toNat

structure TypeCodeInfo where
  code : Nat
  rowLo : Int
  rowHi : Int
  colLo : Int
  colHi : Int
  deriving Inhabited

def checkTypeInfo (cells : List Cell) (info : TypeCodeInfo) : Bool :=
  (cells.length == 7) && decide cells.Nodup && cells.contains origin &&
  cells.all (fun p => decide (-6 ≤ p.1 ∧ p.1 ≤ 6 ∧ -6 ≤ p.2 ∧ p.2 ≤ 6 ∧
    info.rowLo ≤ p.1 ∧ p.1 ≤ info.rowHi ∧ info.colLo ≤ p.2 ∧ p.2 ≤ info.colHi)) &&
  (powerCode (cells.map rootIndex) == info.code)

theorem checkTypeInfo_sound {cells : List Cell} {info : TypeCodeInfo}
    (h : checkTypeInfo cells info = true) :
    cells.length = 7 ∧ cells.Nodup ∧ origin ∈ cells ∧
    (∀ p ∈ cells, -6 ≤ p.1 ∧ p.1 ≤ 6 ∧ -6 ≤ p.2 ∧ p.2 ≤ 6 ∧
      info.rowLo ≤ p.1 ∧ p.1 ≤ info.rowHi ∧ info.colLo ≤ p.2 ∧ p.2 ≤ info.colHi) ∧
    powerCode (cells.map rootIndex) = info.code := by
  simpa only [checkTypeInfo, Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq,
    List.contains_iff_mem, List.all_eq_true, and_assoc] using h

def checkTypeTree (orientation : Nat) : LookupTree ShapeEntry → LookupTree TypeCodeInfo → Bool
  | .leaf entry, .leaf info =>
      checkTypeInfo (entry.cells.map (dihedralIso orientation).equiv) info
  | .branch n left right, .branch n' left' right' =>
      (n == n') && checkTypeTree orientation left left' && checkTypeTree orientation right right'
  | _, _ => false

theorem checkTypeTree_branch (orientation n : Nat) (left right : LookupTree ShapeEntry)
    (li ri : LookupTree TypeCodeInfo)
    (hl : checkTypeTree orientation left li = true)
    (hr : checkTypeTree orientation right ri = true) :
    checkTypeTree orientation (.branch n left right) (.branch n li ri) = true := by
  simp only [checkTypeTree, beq_self_eq_true, Bool.true_and, hl, hr, Bool.and_self]

theorem checkTypeTree_sound (orientation : Nat) (shapes : LookupTree ShapeEntry)
    (infos : LookupTree TypeCodeInfo) (h : checkTypeTree orientation shapes infos = true)
    (index : Nat) :
    checkTypeInfo ((shapes.lookup index).cells.map (dihedralIso orientation).equiv)
      (infos.lookup index) = true := by
  induction shapes generalizing infos index with
  | leaf entry =>
      cases infos with
      | leaf info => exact h
      | branch n left right => simp [checkTypeTree] at h
  | branch n left right ihl ihr =>
      cases infos with
      | leaf info => simp [checkTypeTree] at h
      | branch n' li ri =>
          have hh : (n = n' ∧ checkTypeTree orientation left li = true) ∧
              checkTypeTree orientation right ri = true := by
            simpa only [checkTypeTree, Bool.and_eq_true, beq_iff_eq] using h
          obtain ⟨⟨rfl,hl⟩,hr⟩ := hh
          simp only [LookupTree.lookup]
          split
          · exact ihl li hl index
          · exact ihr ri hr (index-n)

end LockedHeptomino.Encoding

import LockedHeptomino.WitnessCatalog
import LockedHeptomino.DigitEncoding

namespace LockedHeptomino.Encoding

def cellIndex (p : Cell) : Nat := p.1.toNat * 16 + p.2.toNat

def witnessCells (w : SplitWitness) : List Cell := w.firstLeft ++ w.firstRight

def witnessCodeCheck (w : SplitWitness) (code : Nat) : Bool :=
  decide ((witnessCells w).length < 16) &&
  (witnessCells w).all (fun p => decide (0 ≤ p.1 ∧ p.1 < 16 ∧ 0 ≤ p.2 ∧ p.2 < 16)) &&
  (powerCode ((witnessCells w).map cellIndex) == code)

theorem witnessCodeCheck_sound {w : SplitWitness} {code : Nat}
    (h : witnessCodeCheck w code = true) :
    (witnessCells w).length < 16 ∧
    (∀ p ∈ witnessCells w, 0 ≤ p.1 ∧ p.1 < 16 ∧ 0 ≤ p.2 ∧ p.2 < 16) ∧
    powerCode ((witnessCells w).map cellIndex) = code := by
  simpa only [witnessCodeCheck, Bool.and_eq_true, decide_eq_true_eq,
    List.all_eq_true, beq_iff_eq, and_assoc] using h

inductive CodeTree where
  | leaf (code : Nat)
  | node (threshold : Nat) (left right : CodeTree)

def CodeTree.get : CodeTree → Nat → Nat
  | .leaf code, _ => code
  | .node threshold left right, index =>
      if index < threshold then left.get index else right.get index

def codesCheck : WitnessTree → CodeTree → Bool
  | .leaf w, .leaf code => witnessCodeCheck w code
  | .node bound left right, .node bound' left' right' =>
      (bound == bound') && codesCheck left left' && codesCheck right right'
  | _, _ => false

theorem codesCheck_node (bound : Nat) (left right : WitnessTree) (lc rc : CodeTree)
    (hl : codesCheck left lc = true) (hr : codesCheck right rc = true) :
    codesCheck (.node bound left right) (.node bound lc rc) = true := by
  simp only [codesCheck, beq_self_eq_true, Bool.true_and, hl, hr, Bool.and_self]

theorem codesCheck_sound (tree : WitnessTree) (codes : CodeTree)
    (h : codesCheck tree codes = true) (index : Nat) :
    witnessCodeCheck (tree.get index) (codes.get index) = true := by
  induction tree generalizing codes with
  | leaf w =>
      cases codes with
      | leaf code => exact h
      | node bound l r => simp [codesCheck] at h
  | node bound left right ihl ihr =>
      cases codes with
      | leaf code => simp [codesCheck] at h
      | node bound' lc rc =>
          have hh : (bound = bound' ∧ codesCheck left lc = true) ∧
              codesCheck right rc = true := by
            simpa only [codesCheck, Bool.and_eq_true, beq_iff_eq] using h
          obtain ⟨⟨rfl,hl⟩,hr⟩ := hh
          simp only [WitnessTree.get, CodeTree.get]
          split
          · exact ihl lc hl
          · exact ihr rc hr

end LockedHeptomino.Encoding

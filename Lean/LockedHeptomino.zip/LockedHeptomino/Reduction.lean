import LockedHeptomino.Isometry

namespace LockedHeptomino

def HeptominoTiling.map {h w : Nat} (t : HeptominoTiling h w)
    (e : GridIso) (h' w' : Nat) (hb : e.map (rectangle h w) = rectangle h' w') :
    HeptominoTiling h' w' where
  tiles := t.tiles.image e.map
  connected := by
    intro s hs
    obtain ⟨a,ha,rfl⟩ := Finset.mem_image.mp hs
    exact e.connected_map (t.connected a ha)
  size := by
    intro s hs
    obtain ⟨a,ha,rfl⟩ := Finset.mem_image.mp hs
    simpa using t.size a ha
  disjoint := by
    intro s hs r hr hsr
    obtain ⟨a,ha,rfl⟩ := Finset.mem_image.mp hs
    obtain ⟨b,hb,rfl⟩ := Finset.mem_image.mp hr
    exact e.disjoint_map (t.disjoint ha hb (fun he => hsr (congrArg e.map he)))
  covers := by
    rw [Finset.image_biUnion]
    change (t.tiles.biUnion fun s => s.image e.equiv) = _
    rw [← Finset.biUnion_image]
    change e.map (t.tiles.biUnion id) = _
    rw [t.covers, hb]

theorem HeptominoTiling.map_locked {h w : Nat} (t : HeptominoTiling h w)
    (hl : t.Locked) (e : GridIso) (h' w' : Nat)
    (hb : e.map (rectangle h w) = rectangle h' w') : (t.map e h' w' hb).Locked := by
  intro a ha b hb hab
  obtain ⟨c,hc,rfl⟩ := Finset.mem_image.mp ha
  obtain ⟨d,hd,rfl⟩ := Finset.mem_image.mp hb
  exact e.rigid_map (hl c hc d hd (fun he => hab (congrArg e.map he)))

theorem transpose_rectangle (h w : Nat) : transposeIso.map (rectangle h w) = rectangle w h := by
  ext p
  change p ∈ transpose (rectangle h w) ↔ _
  rw [mem_transpose_iff, mem_rectangle, mem_rectangle]
  simp only [transposeCell]
  tauto

noncomputable def HeptominoTiling.tileAt {h w : Nat} (t : HeptominoTiling h w)
    (p : Cell) : Finset Cell :=
  if hp : p ∈ rectangle h w then Classical.choose (t.tile_exists hp) else ∅

theorem HeptominoTiling.tileAt_spec {h w : Nat} (t : HeptominoTiling h w)
    {p : Cell} (hp : p ∈ rectangle h w) :
    t.tileAt p ∈ t.tiles ∧ p ∈ t.tileAt p := by
  simp only [HeptominoTiling.tileAt, dif_pos hp]
  exact Classical.choose_spec (t.tile_exists hp)

/-- Only actual top/left walls (and, for a strip, its right wall) are imposed.
Tiles are allowed to extend past the open bottom and right patch edges. -/
def PatchValid (height width : Nat) (strip : Bool) (tile : Cell → Finset Cell) : Prop :=
  (∀ p ∈ rectangle height width,
    p ∈ tile p ∧ Connected (tile p) ∧ (tile p).card = 7 ∧
    ∀ q ∈ tile p, 0 ≤ q.1 ∧ 0 ≤ q.2 ∧ (strip = true → q.2 < width)) ∧
  (∀ p ∈ rectangle height width, ∀ q ∈ rectangle height width,
    Adjacent p q → Compatible (tile p) (tile q))

theorem HeptominoTiling.patchValid {h w : Nat} (t : HeptominoTiling h w)
    (hl : t.Locked) (ph pw : Nat) (strip : Bool) (hh : ph ≤ h) (hw : pw ≤ w)
    (hs : strip = true → w = pw) : PatchValid ph pw strip t.tileAt := by
  have hsub : rectangle ph pw ⊆ rectangle h w := by
    intro p hp
    rw [mem_rectangle] at hp ⊢
    omega
  constructor
  · intro p hp
    obtain ⟨ht,hp'⟩ := t.tileAt_spec (hsub hp)
    refine ⟨hp',t.connected _ ht,t.size _ ht,?_⟩
    intro q hq
    have hb := (mem_rectangle h w q).mp (t.tile_subset ht hq)
    refine ⟨hb.1,hb.2.2.1,?_⟩
    intro hstrip
    have := hs hstrip
    omega
  · intro p hp q hq _
    exact t.compatible hl (t.tileAt_spec (hsub hp)).1 (t.tileAt_spec (hsub hq)).1

/-- The six finite computational lemmas required by the geometric theorem. -/
structure LocalObstructions : Prop where
  quadrant : ∀ tile, ¬ PatchValid 7 7 false tile
  strip : ∀ width, 2 ≤ width → width ≤ 6 → ∀ tile, ¬ PatchValid 7 width true tile

theorem no_locked_tall_rectangle (obstructions : LocalObstructions)
    {h w : Nat} (hh : 7 ≤ h) (hw : 2 ≤ w) (t : HeptominoTiling h w) : ¬ t.Locked := by
  intro hl
  by_cases hw7 : 7 ≤ w
  · exact obstructions.quadrant t.tileAt
      (t.patchValid hl 7 7 false hh hw7 (by simp))
  · exact obstructions.strip w hw (by omega) t.tileAt
      (t.patchValid hl 7 w true hh (by omega) (by simp))

/-- Pure mathematical reduction from six finite obstructions to all rectangles.
The concrete theorem must instantiate `obstructions` with checked certificates. -/
theorem no_locked_rectangle_of_obstructions (obstructions : LocalObstructions)
    {h w : Nat} (hh : 2 ≤ h) (hw : 2 ≤ w) (t : HeptominoTiling h w) : ¬ t.Locked := by
  rcases t.long_side (by omega) (by omega) with htall | wtall
  · exact no_locked_tall_rectangle obstructions htall hw t
  · intro hl
    have ht := t.map_locked hl transposeIso w h (transpose_rectangle h w)
    exact no_locked_tall_rectangle obstructions wtall hh _ ht

end LockedHeptomino

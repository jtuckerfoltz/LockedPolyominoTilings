import LockedHeptomino.Geometry
import Mathlib.Data.Finset.Card
import Mathlib.Data.Nat.Prime.Defs
import Mathlib.Algebra.BigOperators.Group.Finset.Basic

namespace LockedHeptomino

def rectangle (height width : Nat) : Finset Cell :=
  ((Finset.range height).product (Finset.range width)).image
    (fun p : Nat × Nat => ((p.1 : Int), (p.2 : Int)))

@[simp] theorem mem_rectangle (height width : Nat) (p : Cell) :
    p ∈ rectangle height width ↔
      0 ≤ p.1 ∧ p.1 < height ∧ 0 ≤ p.2 ∧ p.2 < width := by
  simp only [rectangle, Finset.mem_image]
  constructor
  · rintro ⟨⟨r,c⟩, hp, rfl⟩
    have hr := Finset.mem_range.mp (Finset.mem_product.mp hp).1
    have hc := Finset.mem_range.mp (Finset.mem_product.mp hp).2
    exact ⟨by omega, by omega, by omega, by omega⟩
  · rintro ⟨hr0,hr,hc0,hc⟩
    exact ⟨(p.1.toNat,p.2.toNat), Finset.mem_product.mpr
      ⟨Finset.mem_range.mpr (by omega), Finset.mem_range.mpr (by omega)⟩, by
      apply Prod.ext <;> simp <;> omega⟩

@[simp] theorem rectangle_card (height width : Nat) :
    (rectangle height width).card = height * width := by
  rw [rectangle, Finset.card_image_of_injective]
  · simp
  · intro a b h
    apply Prod.ext <;> simp_all only [Prod.mk.injEq, Nat.cast_inj]

/-- A standard finite partition into connected sets of seven grid cells. -/
structure HeptominoTiling (height width : Nat) where
  tiles : Finset (Finset Cell)
  connected : ∀ s ∈ tiles, Connected s
  size : ∀ s ∈ tiles, s.card = 7
  disjoint : (tiles : Set (Finset Cell)).PairwiseDisjoint id
  covers : tiles.biUnion id = rectangle height width

/-- The original split is the unique unordered split into two heptominoes. -/
def RigidPair (a b : Finset Cell) : Prop :=
  ∀ c d : Finset Cell, Connected c → Connected d → c.card = 7 → d.card = 7 →
    Disjoint c d → c ∪ d = a ∪ b →
      (c = a ∧ d = b) ∨ (c = b ∧ d = a)

def HeptominoTiling.Locked {h w : Nat} (tiling : HeptominoTiling h w) : Prop :=
  ∀ a ∈ tiling.tiles, ∀ b ∈ tiling.tiles, a ≠ b → RigidPair a b

/-- Neighboring cells either belong to the same tile or to a rigid disjoint pair. -/
def Compatible (a b : Finset Cell) : Prop :=
  a = b ∨ (Disjoint a b ∧ RigidPair a b)

theorem HeptominoTiling.area {h w : Nat} (tiling : HeptominoTiling h w) :
    h * w = tiling.tiles.card * 7 := by
  calc
    h * w = (rectangle h w).card := (rectangle_card h w).symm
    _ = (tiling.tiles.biUnion id).card := congrArg Finset.card tiling.covers.symm
    _ = ∑ s ∈ tiling.tiles, s.card := Finset.card_biUnion tiling.disjoint
    _ = tiling.tiles.card * 7 := Finset.sum_const_nat tiling.size

theorem HeptominoTiling.seven_dvd_area {h w : Nat} (tiling : HeptominoTiling h w) :
    7 ∣ h * w := by
  rw [tiling.area]
  exact Nat.dvd_mul_left 7 tiling.tiles.card

theorem HeptominoTiling.long_side {h w : Nat} (tiling : HeptominoTiling h w)
    (hh : 0 < h) (hw : 0 < w) : 7 ≤ h ∨ 7 ≤ w := by
  have hp : Nat.Prime 7 := by decide
  rcases hp.dvd_mul.mp tiling.seven_dvd_area with hd | hd
  · exact Or.inl (Nat.le_of_dvd hh hd)
  · exact Or.inr (Nat.le_of_dvd hw hd)

theorem HeptominoTiling.tile_subset {h w : Nat} (tiling : HeptominoTiling h w)
    {s : Finset Cell} (hs : s ∈ tiling.tiles) : s ⊆ rectangle h w := by
  intro p hp
  rw [← tiling.covers]
  exact Finset.mem_biUnion.mpr ⟨s, hs, hp⟩

theorem HeptominoTiling.tile_exists {h w : Nat} (tiling : HeptominoTiling h w)
    {p : Cell} (hp : p ∈ rectangle h w) : ∃ s ∈ tiling.tiles, p ∈ s := by
  rw [← tiling.covers] at hp
  exact Finset.mem_biUnion.mp hp

theorem HeptominoTiling.compatible {h w : Nat} (tiling : HeptominoTiling h w)
    (hl : tiling.Locked) {a b : Finset Cell}
    (ha : a ∈ tiling.tiles) (hb : b ∈ tiling.tiles) : Compatible a b := by
  by_cases hab : a = b
  · exact Or.inl hab
  · exact Or.inr ⟨tiling.disjoint ha hb hab, hl a ha b hb hab⟩

end LockedHeptomino

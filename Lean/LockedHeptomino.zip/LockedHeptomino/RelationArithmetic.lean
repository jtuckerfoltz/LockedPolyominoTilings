import LockedHeptomino.Relations
import LockedHeptomino.TypeEncoding
import LockedHeptomino.WitnessEncoding

namespace LockedHeptomino.Encoding

set_option maxRecDepth 4096

theorem list_map_toFinset (cells : List Cell) (f : Cell → Cell) :
    (cells.map f).toFinset = cells.toFinset.image f := by
  ext p
  simp

/-- Equal sparse codes identify finite cell sets whenever equal numeric tags
identify cells.  The tags themselves need not be globally injective. -/
theorem tagged_sets_eq {left right : List (Cell × Nat)}
    (hl : left.length < 16) (hr : right.length < 16)
    (hcode : powerCode (left.map Prod.snd) = powerCode (right.map Prod.snd))
    (hmatch : ∀ l ∈ left, ∀ r ∈ right, l.2 = r.2 → l.1 = r.1) :
    (left.map Prod.fst).toFinset = (right.map Prod.fst).toFinset := by
  have hm := powerCode_equal_members (by simpa using hl) (by simpa using hr) hcode
  ext p
  simp only [List.mem_toFinset, List.mem_map]
  constructor
  · rintro ⟨l, hll, hlp⟩
    have hi : l.2 ∈ right.map Prod.snd := (hm l.2).mp (List.mem_map.mpr ⟨l, hll, rfl⟩)
    obtain ⟨r, hrr, hrl⟩ := List.mem_map.mp hi
    exact ⟨r, hrr, (hmatch l hll r hrr hrl.symm).symm.trans hlp⟩
  · rintro ⟨r, hrr, hrp⟩
    have hi : r.2 ∈ left.map Prod.snd := (hm r.2).mpr (List.mem_map.mpr ⟨r, hrr, rfl⟩)
    obtain ⟨l, hll, hlr⟩ := List.mem_map.mp hi
    exact ⟨l, hll, (hmatch l hll r hrr hlr).trans hrp⟩

theorem rootIndex_linear {p : Cell} (hr : -6 ≤ p.1) (hc : -6 ≤ p.2) :
    (rootIndex p : Int) = 16 * p.1 + p.2 + 119 := by
  have hr' : 0 ≤ p.1 + 7 := by omega
  have hc' : 0 ≤ p.2 + 7 := by omega
  simp only [rootIndex, Int.natCast_add, Int.natCast_mul,
    Int.toNat_of_nonneg hr', Int.toNat_of_nonneg hc']
  omega

theorem cellIndex_linear {p : Cell} (hr : 0 ≤ p.1) (hc : 0 ≤ p.2) :
    (cellIndex p : Int) = 16 * p.1 + p.2 := by
  simp only [cellIndex, Int.natCast_add, Int.natCast_mul,
    Int.toNat_of_nonneg hr, Int.toNat_of_nonneg hc]
  omega

theorem cell_eq_of_linear {p q : Cell}
    (hp0 : 0 ≤ p.2) (hp16 : p.2 < 16) (hq0 : 0 ≤ q.2) (hq16 : q.2 < 16)
    (h : 16 * p.1 + p.2 = 16 * q.1 + q.2) : p = q := by
  apply Prod.ext <;> omega

theorem aligned_tag_match {p q offset : Cell} {sourcePad witnessPad : Nat}
    (hpR : -6 ≤ p.1) (hpC : -6 ≤ p.2)
    (hqR : 0 ≤ q.1) (hqC : 0 ≤ q.2) (hqC16 : q.2 < 16)
    (hc0 : 0 ≤ p.2 + offset.2) (hc16 : p.2 + offset.2 < 16)
    (hpad : (witnessPad : Int) - sourcePad = 119 - (16 * offset.1 + offset.2))
    (htag : rootIndex p + sourcePad = cellIndex q + witnessPad) : shiftCell offset p = q := by
  have hpidx := rootIndex_linear hpR hpC
  have hqidx := cellIndex_linear hqR hqC
  have heq := congrArg (fun n : Nat => (n : Int)) htag
  simp only [Int.natCast_add] at heq
  apply cell_eq_of_linear hc0 hc16 hqC hqC16
  simp only [shiftCell]
  omega

def pairTags (left right : List Cell) (leftOffset rightOffset : Cell)
    (leftPad rightPad : Nat) : List (Cell × Nat) :=
  left.map (fun p => (shiftCell leftOffset p, rootIndex p + leftPad)) ++
  right.map (fun p => (shiftCell rightOffset p, rootIndex p + rightPad))

def witnessTags (cells : List Cell) (pad : Nat) : List (Cell × Nat) :=
  cells.map fun p => (p, cellIndex p + pad)

theorem pairTags_code (left right : List Cell) (lo ro : Cell) (lp rp : Nat) :
    powerCode ((pairTags left right lo ro lp rp).map Prod.snd) =
      powerCode (left.map rootIndex) * 16 ^ lp + powerCode (right.map rootIndex) * 16 ^ rp := by
  simp only [pairTags, List.map_append, List.map_map, Function.comp_def]
  rw [powerCode_append]
  have hl := powerCode_shift (left.map rootIndex) lp
  have hr := powerCode_shift (right.map rootIndex) rp
  simpa only [List.map_map, Function.comp_def] using congrArg₂ (· + ·) hl hr

theorem witnessTags_code (cells : List Cell) (pad : Nat) :
    powerCode ((witnessTags cells pad).map Prod.snd) =
      powerCode (cells.map cellIndex) * 16 ^ pad := by
  simpa only [witnessTags, List.map_map, Function.comp_def] using
    powerCode_shift (cells.map cellIndex) pad

theorem arithmetic_union_eq {left right : List Cell} {li ri : TypeCodeInfo}
    (hl : checkTypeInfo left li = true) (hr : checkTypeInfo right ri = true)
    {w : SplitWitness} {wc : Nat} (hw : witnessCodeCheck w wc = true)
    {lo ro : Cell} {lp rp wp : Nat}
    (hlcol : 0 ≤ li.colLo + lo.2 ∧ li.colHi + lo.2 < 16)
    (hrcol : 0 ≤ ri.colLo + ro.2 ∧ ri.colHi + ro.2 < 16)
    (hlpad : (wp : Int) - lp = 119 - (16 * lo.1 + lo.2))
    (hrpad : (wp : Int) - rp = 119 - (16 * ro.1 + ro.2))
    (heq : li.code * 16 ^ lp + ri.code * 16 ^ rp = wc * 16 ^ wp) :
    translate lo left.toFinset ∪ translate ro right.toFinset = w.union := by
  obtain ⟨hlen, _, _, hbounds, hcode⟩ := checkTypeInfo_sound hl
  obtain ⟨rlen, _, _, rbounds, rcode⟩ := checkTypeInfo_sound hr
  obtain ⟨wlen, wbounds, wcode⟩ := witnessCodeCheck_sound hw
  have he : ((pairTags left right lo ro lp rp).map Prod.fst).toFinset =
      ((witnessTags (witnessCells w) wp).map Prod.fst).toFinset := by
    apply tagged_sets_eq
    · simp only [pairTags, List.length_append, List.length_map, hlen, rlen]
      omega
    · simpa only [witnessTags, List.length_map] using wlen
    · simpa only [pairTags_code, witnessTags_code, hcode, rcode, wcode] using heq
    · intro a ha b hb htag
      obtain ⟨q, hq, rfl⟩ := List.mem_map.mp hb
      have hqb := wbounds q hq
      rcases List.mem_append.mp ha with hal | har
      · obtain ⟨p, hp, rfl⟩ := List.mem_map.mp hal
        have hpb := hbounds p hp
        exact aligned_tag_match hpb.1 hpb.2.2.1 hqb.1 hqb.2.2.1 hqb.2.2.2
          (by omega) (by omega) hlpad htag
      · obtain ⟨p, hp, rfl⟩ := List.mem_map.mp har
        have hpb := rbounds p hp
        exact aligned_tag_match hpb.1 hpb.2.2.1 hqb.1 hqb.2.2.1 hqb.2.2.2
          (by omega) (by omega) hrpad htag
  simpa [pairTags, witnessTags, List.map_append, List.map_map, Function.comp_def,
    list_map_toFinset, translate, witnessCells, SplitWitness.union] using he

theorem witness_union_card {w : SplitWitness} (hw : w.check = true) : w.union.card = 14 := by
  simp only [SplitWitness.check, Bool.and_eq_true] at hw
  rcases hw with ⟨⟨⟨⟨⟨⟨⟨⟨⟨hc, hd⟩, _⟩, _⟩, hcd⟩, _⟩, _⟩, _⟩, _⟩, _⟩
  have hc7 := (tileOrderCheck_sound _ hc).2
  have hd7 := (tileOrderCheck_sound _ hd).2
  rw [SplitWitness.union, Finset.card_union_of_disjoint ((listDisjointCheck_iff _ _).mp hcd), hc7, hd7]

structure FlexibleRecord where
  target : Nat
  witness : Nat
  orientation : Nat
  offset : Cell
  leftPad : Nat
  rightPad : Nat
  witnessPad : Nat

def flexibleCheck (infos : Nat → Nat → TypeCodeInfo) (wcodes : Nat → Nat)
    (d a : Nat) (entry : FlexibleRecord) : Bool :=
  let left := infos entry.orientation a
  let right := infos entry.orientation entry.target
  let delta := (dihedralIso entry.orientation).equiv (direction d)
  decide (entry.orientation < 8) && decide (entry.target < 5320) &&
  decide ((entry.rightPad : Int) - entry.leftPad = 16 * delta.1 + delta.2) &&
  decide ((entry.witnessPad : Int) - entry.leftPad =
    119 - (16 * entry.offset.1 + entry.offset.2)) &&
  decide (0 ≤ left.colLo + entry.offset.2 ∧ left.colHi + entry.offset.2 < 16) &&
  decide (0 ≤ right.colLo + delta.2 + entry.offset.2 ∧
    right.colHi + delta.2 + entry.offset.2 < 16) &&
  (left.code * 16 ^ entry.leftPad + right.code * 16 ^ entry.rightPad ==
    wcodes entry.witness * 16 ^ entry.witnessPad)

theorem orientedCells_finset (orientation index : Nat) :
    (orientedCells orientation index).toFinset =
      (dihedralIso orientation).map (Generated.typeShape index) := by
  rw [orientedCells, list_map_toFinset]
  rfl

theorem translate_compose (v u : Cell) (s : Finset Cell) :
    translate v (translate u s) = translate (shiftCell v u) s := by
  simp only [translate, Finset.image_image]
  congr 1
  funext p
  ext <;> simp [Function.comp_def, shiftCell, Int.add_assoc]

theorem dihedral_map_translate (orientation : Nat) (delta : Cell) (s : Finset Cell) :
    (dihedralIso orientation).map (translate delta s) =
      translate ((dihedralIso orientation).equiv delta) ((dihedralIso orientation).map s) := by
  simp only [GridIso.map, translate, Finset.image_image]
  congr 1
  funext p
  exact dihedral_shift orientation delta p

theorem trans_translate_map (e : GridIso) (offset : Cell) (s : Finset Cell) :
    (e.trans (translateIso offset)).map s = translate offset (e.map s) := by
  simp [GridIso.map, GridIso.trans, translateIso, translate, Finset.image_image,
    Function.comp_def]

theorem flexibleCheck_sound
    (infos : Nat → Nat → TypeCodeInfo) (witnesses : Nat → SplitWitness) (wcodes : Nat → Nat)
    (hi : ∀ orientation < 8, ∀ index,
      checkTypeInfo (orientedCells orientation index) (infos orientation index) = true)
    (hw : ∀ index, (witnesses index).check = true)
    (hwc : ∀ index, witnessCodeCheck (witnesses index) (wcodes index) = true)
    (d a : Nat) (entry : FlexibleRecord)
    (hc : flexibleCheck infos wcodes d a entry = true) :
    ¬ Compatible (Generated.typeShape a) (translate (direction d) (Generated.typeShape entry.target)) := by
  simp only [flexibleCheck, Bool.and_eq_true, decide_eq_true_eq, beq_iff_eq] at hc
  rcases hc with ⟨⟨⟨⟨⟨⟨ho, _⟩, hdelta⟩, hpad⟩, hlcol⟩, hrcol⟩, heq⟩
  let delta := (dihedralIso entry.orientation).equiv (direction d)
  let iso := (dihedralIso entry.orientation).trans (translateIso entry.offset)
  have hleft := hi entry.orientation ho a
  have hright := hi entry.orientation ho entry.target
  have hu : translate entry.offset (orientedCells entry.orientation a).toFinset ∪
      translate (shiftCell entry.offset delta)
        (orientedCells entry.orientation entry.target).toFinset = (witnesses entry.witness).union := by
    apply arithmetic_union_eq hleft hright (hwc entry.witness) hlcol
    · simpa only [shiftCell, Int.add_assoc] using hrcol
    · exact hpad
    · change (entry.witnessPad : Int) - entry.rightPad =
        119 - (16 * (delta.1 + entry.offset.1) + (delta.2 + entry.offset.2))
      change (entry.rightPad : Int) - entry.leftPad = 16 * delta.1 + delta.2 at hdelta
      omega
    · exact heq
  have hmap : iso.map (Generated.typeShape a ∪
      translate (direction d) (Generated.typeShape entry.target)) =
      (witnesses entry.witness).union := by
    simpa only [iso, GridIso.map_union, trans_translate_map, dihedral_map_translate,
      translate_compose, ← orientedCells_finset, delta] using hu
  have hca : (Generated.typeShape a).card = 7 := by
    have hl := checkTypeInfo_sound hleft
    have hh : (orientedCells entry.orientation a).toFinset.card = 7 :=
      (List.toFinset_card_of_nodup hl.2.1).trans hl.1
    simpa only [orientedCells_finset, GridIso.map_card] using hh
  intro hcompat
  rcases hcompat with hequal | ⟨_, hrigid⟩
  · have hsize := congrArg Finset.card hmap
    rw [← hequal, Finset.union_self, GridIso.map_card, hca,
      witness_union_card (hw entry.witness)] at hsize
    omega
  · exact (witnesses entry.witness).not_rigid_of_isometry (hw entry.witness)
      iso _ _ hmap hrigid

/-- A compact, untrusted record. All decoded geometry is checked below.
Bits 0..12: target; 13..28: witness; 29..31: orientation;
32..34 and 35..37: canonical translation coordinates. -/
def decodeFlexible (d packed : Nat) : FlexibleRecord :=
  let orientation := packed / 536870912 % 8
  let tr := packed / 4294967296 % 8
  let tc := packed / 34359738368 % 8
  let delta := (dihedralIso orientation).equiv (direction d)
  let displacement := 16 * delta.1 + delta.2
  let lp := (-displacement).toNat
  { target := packed % 8192
    witness := packed / 8192 % 65536
    orientation := orientation
    offset := (tr, tc)
    leftPad := lp
    rightPad := displacement.toNat
    witnessPad := 119 - (16 * tr + tc) + lp }

def packedTarget (packed : Nat) : Nat := packed % 8192

def packedFlexibleCheck (infos : Nat → Nat → TypeCodeInfo) (wcodes : Nat → Nat)
    (d a packed : Nat) : Bool := flexibleCheck infos wcodes d a (decodeFlexible d packed)

def relationRowCheck (infos : Nat → Nat → TypeCodeInfo) (wcodes : Nat → Nat)
    (incidence : Cell → Nat) (same : Nat → Nat → Nat) (forbidden : Nat → Nat → Nat)
    (d a : Nat) (records : List Nat) : Bool :=
  records.all (packedFlexibleCheck infos wcodes d a) &&
  coverageCheck (forbidden d a)
    (overlapForbidden incidence same d a (typeCells a)) (targetsMask packedTarget records)

theorem relationRowCheck_sound
    (infos : Nat → Nat → TypeCodeInfo) (witnesses : Nat → SplitWitness) (wcodes : Nat → Nat)
    (hi : ∀ orientation < 8, ∀ index,
      checkTypeInfo (orientedCells orientation index) (infos orientation index) = true)
    (hw : ∀ index, (witnesses index).check = true)
    (hwc : ∀ index, witnessCodeCheck (witnesses index) (wcodes index) = true)
    {incidence : Cell → Nat} {same : Nat → Nat → Nat} {forbidden : Nat → Nat → Nat}
    (hinc : IncidenceSound Generated.typeShape incidence)
    (hsame : EqualIndexSound Generated.typeShape same)
    {d a b : Nat} (hd : d < 4) (ha : a < 5320) (hb : b < 5320) {records : List Nat}
    (hcheck : relationRowCheck infos wcodes incidence same forbidden d a records = true)
    (hbit : (forbidden d a).testBit b = true) :
    ¬ Compatible (Generated.typeShape a) (translate (direction d) (Generated.typeShape b)) := by
  have hh : records.all (packedFlexibleCheck infos wcodes d a) = true ∧
      coverageCheck (forbidden d a) (overlapForbidden incidence same d a (typeCells a))
        (targetsMask packedTarget records) = true := by
    simpa only [relationRowCheck, Bool.and_eq_true] using hcheck
  apply forbiddenRow_sound hinc hsame hd ha hb (cells := typeCells a) rfl hh.1 _ hh.2 hbit
  intro entry _ he
  exact flexibleCheck_sound infos witnesses wcodes hi hw hwc d a (decodeFlexible d entry) he

theorem permitted_bit_of_not_forbidden {forbidden b : Nat} (hb : b < 5320)
    (hbit : forbidden.testBit b = false) :
    ((2 ^ 5320 - 1) - forbidden % 2 ^ 5320).testBit b = true := by
  have he : (2 ^ 5320 - 1) - forbidden % 2 ^ 5320 =
      2 ^ 5320 - (forbidden % 2 ^ 5320 + 1) := by omega
  rw [he, Nat.testBit_two_pow_sub_succ (Nat.mod_lt _ (Nat.two_pow_pos _))]
  simp only [hb, decide_true, Bool.true_and, Nat.testBit_mod_two_pow, hbit, Bool.and_false,
    Bool.not_false]

theorem relationRowCheck_permitted
    (infos : Nat → Nat → TypeCodeInfo) (witnesses : Nat → SplitWitness) (wcodes : Nat → Nat)
    (hi : ∀ orientation < 8, ∀ index,
      checkTypeInfo (orientedCells orientation index) (infos orientation index) = true)
    (hw : ∀ index, (witnesses index).check = true)
    (hwc : ∀ index, witnessCodeCheck (witnesses index) (wcodes index) = true)
    {incidence : Cell → Nat} {same : Nat → Nat → Nat} {forbidden : Nat → Nat → Nat}
    (hinc : IncidenceSound Generated.typeShape incidence)
    (hsame : EqualIndexSound Generated.typeShape same)
    {d a b : Nat} (hd : d < 4) (ha : a < 5320) (hb : b < 5320) {records : List Nat}
    (hcheck : relationRowCheck infos wcodes incidence same forbidden d a records = true)
    (hcompat : Compatible (Generated.typeShape a) (translate (direction d) (Generated.typeShape b))) :
    ((2 ^ 5320 - 1) - forbidden d a % 2 ^ 5320).testBit b = true := by
  apply permitted_bit_of_not_forbidden hb
  cases hbit : (forbidden d a).testBit b with
  | false => rfl
  | true => exact False.elim (relationRowCheck_sound infos witnesses wcodes hi hw hwc
      hinc hsame hd ha hb hcheck hbit hcompat)

end LockedHeptomino.Encoding

import LockedHeptomino.RelationArithmetic
import LockedHeptomino.Generated.TypeInfo
import LockedHeptomino.Generated.WitnessCodes
import LockedHeptomino.Generated.IncidenceComplete
import LockedHeptomino.Generated.SameIndexComplete
import LockedHeptomino.Generated.PermittedRows

namespace LockedHeptomino.Generated

open LockedHeptomino.Encoding

set_option maxRecDepth 16384
set_option exponentiation.threshold 16384

def localRowCheck (d a : Nat) (records : List Nat) : Bool :=
  relationRowCheck typeInfo witnessCode incidence sameIndex PermittedRows.forbiddenRow d a records

def LocalRowSound (d a : Nat) : Prop :=
  ∀ b < 5320, Compatible (typeShape a) (translate (direction d) (typeShape b)) →
    (PermittedRows.permittedRow d a).testBit b = true

theorem localRowCheck_sound {d a : Nat} (hd : d < 4) (ha : a < 5320)
    {records : List Nat} (hc : localRowCheck d a records = true) : LocalRowSound d a := by
  intro b hb hcompat
  exact relationRowCheck_permitted typeInfo witness witnessCode typeInfo_checked
    witness_checked witness_encoding_checked incidence_sound sameIndex_sound hd ha hb hc hcompat

end LockedHeptomino.Generated

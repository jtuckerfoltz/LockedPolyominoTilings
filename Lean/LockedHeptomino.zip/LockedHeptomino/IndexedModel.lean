import LockedHeptomino.Reduction
import LockedHeptomino.CSPTable

namespace LockedHeptomino

def cellPosition (width index : Nat) : Cell :=
  ((index / width : Nat), (index % width : Nat))

theorem cellPosition_mem {h w : Nat} (hw : 0 < w) (i : Fin (h * w)) :
    cellPosition w i.val ∈ rectangle h w := by
  rw [mem_rectangle]
  have hr : i.val / w < h := (Nat.div_lt_iff_lt_mul hw).mpr i.isLt
  have hc := Nat.mod_lt i.val hw
  simp only [cellPosition]
  exact ⟨Int.natCast_nonneg _, Int.ofNat_lt.mpr hr,
    Int.natCast_nonneg _, Int.ofNat_lt.mpr hc⟩

def Walls (width : Nat) (strip : Bool) (s : Finset Cell) : Prop :=
  ∀ q ∈ s, 0 ≤ q.1 ∧ 0 ≤ q.2 ∧ (strip = true → q.2 < width)

def placedType (types : Nat → Finset Cell) (width cell value : Nat) : Finset Cell :=
  translate (cellPosition width cell) (types value)

/-- Only conditions implied by a genuine locked tiling enter this model. -/
structure IndexedValid (types : Nat → Finset Cell) (h w : Nat) (strip : Bool)
    (assignment : CSP.Assignment (Fin (h * w))) : Prop where
  bounded : ∀ i, assignment i < 5320
  walls : ∀ i, Walls w strip (placedType types w i.val (assignment i))
  compatible : ∀ i j, Adjacent (cellPosition w i.val) (cellPosition w j.val) →
    Compatible (placedType types w i.val (assignment i))
      (placedType types w j.val (assignment j))

def RootedComplete (types : Nat → Finset Cell) : Prop :=
  ∀ s : Finset Cell, Connected s → origin ∈ s → s.card = 7 →
    ∃ value < 5320, types value = s

/-- Initial domains must include every type satisfying the actual walls. -/
def InitialSound (types : Nat → Finset Cell) (h w : Nat) (strip : Bool)
    (initial : CSP.Domains (Fin (h * w))) : Prop :=
  ∀ i value, value < 5320 → Walls w strip (placedType types w i.val value) →
    (initial i).testBit value = true

theorem initial_fits {types : Nat → Finset Cell} {h w : Nat} {strip : Bool}
    {initial : CSP.Domains (Fin (h * w))} (hs : InitialSound types h w strip initial)
    {assignment : CSP.Assignment (Fin (h * w))}
    (hv : IndexedValid types h w strip assignment) : CSP.Fits initial assignment := by
  intro i
  exact hs i (assignment i) (hv.bounded i) (hv.walls i)

/-- Completeness, rather than a trusted generator, supplies the index of each tile. -/
theorem indexed_of_patch {types : Nat → Finset Cell} (hcomplete : RootedComplete types)
    {h w : Nat} (hw : 0 < w) {strip : Bool} {tile : Cell → Finset Cell}
    (hv : PatchValid h w strip tile) :
    ∃ assignment, IndexedValid types h w strip assignment := by
  classical
  have hchoose : ∀ i : Fin (h * w), ∃ value < 5320,
      placedType types w i.val value = tile (cellPosition w i.val) := by
    intro i
    let p := cellPosition w i.val
    have hp := cellPosition_mem hw i
    obtain ⟨hpt,hconn,hcard,hwall⟩ := hv.1 p hp
    have hr : origin ∈ translate (negCell p) (tile p) := by
      apply Finset.mem_image.mpr
      exact ⟨p,hpt,by simp [origin, shiftCell, negCell]⟩
    obtain ⟨value,hbound,hshape⟩ := hcomplete _
      (connected_translate hconn (negCell p)) hr (by simpa using hcard)
    refine ⟨value,hbound,?_⟩
    change translate p (types value) = tile p
    rw [hshape, translate_cancel_neg]
  choose assignment hbound hshape using hchoose
  refine ⟨assignment,⟨hbound,?_,?_⟩⟩
  · intro i
    rw [hshape i]
    exact (hv.1 _ (cellPosition_mem hw i)).2.2.2
  · intro i j hij
    rw [hshape i, hshape j]
    exact hv.2 _ (cellPosition_mem hw i) _ (cellPosition_mem hw j) hij

/-- The integration lemma exposes every computational obligation explicitly. -/
theorem no_patch_of_certificate {types : Nat → Finset Cell}
    (hcomplete : RootedComplete types) {h w : Nat} (hw : 0 < w) (strip : Bool)
    (initial : CSP.Domains (Fin (h * w)))
    (hinitial : InitialSound types h w strip initial)
    (excludes : CSP.Excludes (Fin (h * w)))
    (hsound : CSP.ExcludesSound (IndexedValid types h w strip) excludes)
    (certificate : CSP.Certificate (Fin (h * w)))
    (hcheck : CSP.check excludes certificate initial = true) :
    ∀ tile, ¬ PatchValid h w strip tile := by
  intro tile htile
  obtain ⟨assignment,hvalid⟩ := indexed_of_patch hcomplete hw htile
  exact CSP.check_sound hsound certificate initial hcheck assignment hvalid
    (initial_fits hinitial hvalid)

end LockedHeptomino

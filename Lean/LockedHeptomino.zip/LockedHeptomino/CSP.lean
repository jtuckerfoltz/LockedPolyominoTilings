import Std

/-!
A certificate checker for finite-domain constraint problems.

Values and finite domains are natural numbers and natural-number bitsets.  The
checker deliberately does not know polyomino geometry: its only oracle is a
Boolean test for a forbidden rectangle of values, with an explicit soundness
hypothesis.  All certificate operations preserve every genuine assignment.
-/
namespace LockedHeptomino.CSP

variable {α : Type}

abbrev Domains (α : Type) := α → Nat
abbrev Assignment (α : Type) := α → Nat

/-- A set represented by the positions of the `1` bits of a natural number. -/
def Fits (domains : Domains α) (assignment : Assignment α) : Prop :=
  ∀ i, (domains i).testBit (assignment i) = true

/-- Replace one domain. There is no mutation and no trusted array indexing. -/
def replace [DecidableEq α] (domains : Domains α) (i : α) (value : Nat) : Domains α :=
  fun j => if j = i then value else domains j

/-- Form a finite bitset; repeated values are harmless. -/
def bits : List Nat → Nat
  | [] => 0
  | value :: rest => 2 ^ value ||| bits rest

@[simp] theorem bits_testBit (values : List Nat) (v : Nat) :
    (bits values).testBit v = true ↔ v ∈ values := by
  induction values with
  | nil => simp [bits]
  | cons value rest ih => simp only [bits, Nat.testBit_or, Bool.or_eq_true, Nat.testBit_two_pow, decide_eq_true_eq, ih, List.mem_cons]; exact or_congr eq_comm Iff.rfl

/-- Every bit in `small` occurs in `large`. -/
def subset (small large : Nat) : Bool := (small &&& large) == small

 theorem subset_sound {small large v : Nat} (h : subset small large = true)
    (hv : small.testBit v = true) : large.testBit v = true := by
  have heq : small &&& large = small := by simpa [subset] using h
  have hbit := congrArg (fun n => n.testBit v) heq
  simpa [hv] using hbit

/-
A revision keeps a supplied new domain; its removed bits must be forbidden
against the current target domain. A split need only cover the parent domain:
extra branches and repeated values cannot invalidate an impossibility proof.
-/
mutual
  inductive Certificate (α : Type) where
    | empty (cell : α)
    | revise (source target : α) (newDomain : Nat) (next : Certificate α)
    | split (cell : α) (children : Branches α)
  inductive Branches (α : Type) where
    | nil
    | cons (value : Nat) (child : Certificate α) (rest : Branches α)
end

/-- The branch values, represented as one bitset. -/
def Branches.cover : Branches α → Nat
  | .nil => 0
  | .cons value _ rest => 2 ^ value ||| rest.cover

/-- The oracle has to exclude *every* pair in its two supplied bitsets. -/
abbrev Excludes (α : Type) := α → α → Nat → Nat → Bool

/-- No genuine assignment can realize a rectangle accepted by the oracle. -/
def ExcludesSound (valid : Assignment α → Prop) (excludes : Excludes α) : Prop :=
  ∀ source target left right, excludes source target left right = true →
    ∀ assignment, valid assignment →
      left.testBit (assignment source) = true →
      right.testBit (assignment target) = true → False

/- Pure certificate checking, without search or an external evaluator. -/
mutual
  def check [DecidableEq α] (excludes : Excludes α) : Certificate α → Domains α → Bool
    | .empty cell, domains => domains cell == 0
    | .revise source target newDomain next, domains =>
        excludes source target (domains source ^^^ newDomain) (domains target) &&
          check excludes next (replace domains source newDomain)
    | .split cell children, domains =>
        subset (domains cell) children.cover && checkBranches excludes children cell domains
  def checkBranches [DecidableEq α] (excludes : Excludes α) : Branches α → α → Domains α → Bool
    | .nil, _, _ => true
    | .cons value child rest, cell, domains =>
        check excludes child (replace domains cell (2 ^ value)) &&
          checkBranches excludes rest cell domains
end

 theorem replace_fits [DecidableEq α] {domains : Domains α} {assignment : Assignment α}
    (hfit : Fits domains assignment) (i : α) (newDomain : Nat)
    (hnew : newDomain.testBit (assignment i) = true) :
    Fits (replace domains i newDomain) assignment := by
  intro j
  by_cases h : j = i
  · subst j
    simpa [replace] using hnew
  · simpa [replace, h] using hfit j

 theorem revise_fits [DecidableEq α] {valid : Assignment α → Prop}
    {excludes : Excludes α} (hsound : ExcludesSound valid excludes)
    {domains : Domains α} {assignment : Assignment α}
    (hvalid : valid assignment) (hfit : Fits domains assignment)
    (source target : α) (newDomain : Nat)
    (hcheck : excludes source target (domains source ^^^ newDomain) (domains target) = true) :
    Fits (replace domains source newDomain) assignment := by
  apply replace_fits hfit
  cases hnew : newDomain.testBit (assignment source) with
  | true => rfl
  | false =>
    have hremoved : (domains source ^^^ newDomain).testBit (assignment source) = true := by
      simp [Nat.testBit_xor, hfit source, hnew]
    exact False.elim (hsound source target _ _ hcheck assignment hvalid hremoved (hfit target))

/-- A successful check refutes every genuine assignment fitting the initial domains. -/
theorem check_sound [DecidableEq α] {valid : Assignment α → Prop}
    {excludes : Excludes α} (hsound : ExcludesSound valid excludes)
    (certificate : Certificate α) (domains : Domains α)
    (hcheck : check excludes certificate domains = true)
    (assignment : Assignment α) (hvalid : valid assignment) (hfit : Fits domains assignment) :
    False := by
  induction certificate using Certificate.rec
    (motive_2 := fun children => ∀ cell domains,
      checkBranches excludes children cell domains = true →
      children.cover.testBit (assignment cell) = true → Fits domains assignment → False)
    generalizing domains with
  | empty cell =>
      have hz : domains cell = 0 := by simpa [check] using hcheck
      have hf := hfit cell
      simp [hz] at hf
  | revise source target newDomain next ih =>
      have hh : excludes source target (domains source ^^^ newDomain) (domains target) = true ∧
          check excludes next (replace domains source newDomain) = true := by
        simpa only [check, Bool.and_eq_true] using hcheck
      exact ih _ hh.2 (revise_fits hsound hvalid hfit source target newDomain hh.1)
  | split cell children ih =>
      have hh : subset (domains cell) children.cover = true ∧
          checkBranches excludes children cell domains = true := by
        simpa only [check, Bool.and_eq_true] using hcheck
      exact ih cell domains hh.2 (subset_sound hh.1 (hfit cell)) hfit
  | nil =>
      rename_i cell domains hc hb hf
      simp [Branches.cover] at hb
  | cons value child rest hchild hrest =>
      rename_i cell domains hc hb hf
      have hh : check excludes child (replace domains cell (2 ^ value)) = true ∧
          checkBranches excludes rest cell domains = true := by
        simpa only [checkBranches, Bool.and_eq_true] using hc
      have hv : value = assignment cell ∨ rest.cover.testBit (assignment cell) = true := by
        simpa only [Branches.cover, Nat.testBit_or, Nat.testBit_two_pow,
          Bool.or_eq_true, decide_eq_true_eq] using hb
      rcases hv with hv | hv
      · apply hchild _ hh.1
        apply replace_fits hf
        simp [Nat.testBit_two_pow, hv]
      · exact hrest cell domains hh.2 hv hf

/-- Choosing which side to enumerate changes cost but not the exclusion claim. -/
def orientExcludes (excludes : Excludes α) (reverse : Bool) : Excludes α :=
  fun source target left right =>
    if reverse then excludes target source right left
    else excludes source target left right

 theorem orientExcludes_sound {valid : Assignment α → Prop} {excludes : Excludes α}
    (hsound : ExcludesSound valid excludes) (reverse : Bool) :
    ExcludesSound valid (orientExcludes excludes reverse) := by
  intro source target left right hcheck assignment hvalid hl hr
  cases reverse with
  | false => exact hsound source target left right hcheck assignment hvalid hl hr
  | true => exact hsound target source right left hcheck assignment hvalid hr hl

/-- A propagation step, separated from a search tree for bounded-size checking. -/
structure Revision (α : Type) where
  source : α
  target : α
  newDomain : Nat
  reverse : Bool := false

/-- Apply a block of revisions, without asserting their validity. -/
def applyRevisions [DecidableEq α] : List (Revision α) → Domains α → Domains α
  | [], domains => domains
  | step :: rest, domains =>
      applyRevisions rest (replace domains step.source step.newDomain)

/-- Check just a propagation block, rather than a whole contradiction tree. -/
def checkRevisions [DecidableEq α] (excludes : Excludes α) :
    List (Revision α) → Domains α → Bool
  | [], _ => true
  | step :: rest, domains =>
      orientExcludes excludes step.reverse step.source step.target
        (domains step.source ^^^ step.newDomain) (domains step.target) &&
        checkRevisions excludes rest (replace domains step.source step.newDomain)

 theorem checkRevisions_sound [DecidableEq α] {valid : Assignment α → Prop}
    {excludes : Excludes α} (hsound : ExcludesSound valid excludes)
    (steps : List (Revision α)) (domains : Domains α)
    (hcheck : checkRevisions excludes steps domains = true)
    (assignment : Assignment α) (hvalid : valid assignment) (hfit : Fits domains assignment) :
    Fits (applyRevisions steps domains) assignment := by
  induction steps generalizing domains with
  | nil => exact hfit
  | cons step rest ih =>
      have hh : orientExcludes excludes step.reverse step.source step.target
          (domains step.source ^^^ step.newDomain) (domains step.target) = true ∧
          checkRevisions excludes rest (replace domains step.source step.newDomain) = true := by
        simpa only [checkRevisions, Bool.and_eq_true] using hcheck
      exact ih _ hh.2
        (revise_fits (orientExcludes_sound hsound step.reverse) hvalid hfit
          step.source step.target step.newDomain hh.1)

/-- Explicit state snapshots stop kernel reduction from retaining a long update history. -/
def verifyTransition [DecidableEq α] (excludes : Excludes α) (cells : List α)
    (steps : List (Revision α)) (before after : Domains α) : Bool :=
  checkRevisions excludes steps before &&
    cells.all (fun cell => applyRevisions steps before cell == after cell)

 theorem verifyTransition_sound [DecidableEq α] {valid : Assignment α → Prop}
    {excludes : Excludes α} (hsound : ExcludesSound valid excludes)
    (cells : List α) (hcover : ∀ cell, cell ∈ cells)
    (steps : List (Revision α)) (before after : Domains α)
    (hcheck : verifyTransition excludes cells steps before after = true)
    (assignment : Assignment α) (hvalid : valid assignment) (hfit : Fits before assignment) :
    Fits after assignment := by
  have hh : checkRevisions excludes steps before = true ∧
      cells.all (fun cell => applyRevisions steps before cell == after cell) = true := by
    simpa only [verifyTransition, Bool.and_eq_true] using hcheck
  have hpreserve := checkRevisions_sound hsound steps before hh.1 assignment hvalid hfit
  intro cell
  have heq : applyRevisions steps before cell = after cell :=
    beq_iff_eq.mp (List.all_eq_true.mp hh.2 cell (hcover cell))
  simpa only [heq] using hpreserve cell

 theorem finRange_covers (n : Nat) (cell : Fin n) : cell ∈ List.finRange n := by
  change cell ∈ List.ofFn (fun i : Fin n => i)
  exact List.mem_ofFn.mpr ⟨cell, rfl⟩

end LockedHeptomino.CSP

import Mathlib.Data.List.Count
import Mathlib.Data.List.Perm.Basic
import Mathlib.Algebra.BigOperators.Ring.List
import LockedHeptomino.Prelude

namespace LockedHeptomino.Encoding

/-- A sparse base-sixteen encoding. Repeated indices are counted as digits. -/
def powerCode (xs : List Nat) : Nat := (xs.map (16 ^ ·)).sum

@[simp] theorem powerCode_nil : powerCode [] = 0 := rfl

@[simp] theorem powerCode_cons (a : Nat) (xs : List Nat) :
    powerCode (a :: xs) = 16 ^ a + powerCode xs := rfl

theorem powerCode_append (xs ys : List Nat) :
    powerCode (xs ++ ys) = powerCode xs + powerCode ys := by
  simp [powerCode]

theorem powerCode_shift (xs : List Nat) (k : Nat) :
    powerCode (xs.map (· + k)) = powerCode xs * 16 ^ k := by
  simp only [powerCode, List.map_map, Function.comp_def, pow_add]
  exact List.sum_map_mul_right xs (16 ^ ·) (16 ^ k)

private def lower (xs : List Nat) : List Nat :=
  xs.filterMap fun n => match n with | 0 => none | k + 1 => some k

@[simp] private theorem lower_nil : lower [] = [] := rfl
@[simp] private theorem lower_zero_cons (xs : List Nat) : lower (0 :: xs) = lower xs := rfl
@[simp] private theorem lower_succ_cons (a : Nat) (xs : List Nat) :
    lower ((a + 1) :: xs) = a :: lower xs := rfl

private theorem lower_length (xs : List Nat) : (lower xs).length ≤ xs.length :=
  List.length_filterMap_le _ _

private theorem powerCode_split (xs : List Nat) :
    powerCode xs = xs.count 0 + 16 * powerCode (lower xs) := by
  induction xs with
  | nil => simp
  | cons a xs ih =>
    cases a with
    | zero => simp only [powerCode_cons, pow_zero, List.count_cons, beq_self_eq_true,
        if_true, lower_zero_cons, ih]; omega
    | succ a => simp [List.count_cons, ih, pow_succ]; ring

private theorem count_lower (xs : List Nat) (k : Nat) :
    (lower xs).count k = xs.count (k + 1) := by
  induction xs with
  | nil => simp
  | cons a xs ih =>
    cases a <;> simp [List.count_cons, ih]

private theorem equal_zero_counts {xs ys : List Nat}
    (hx : xs.length < 16) (hy : ys.length < 16)
    (h : powerCode xs = powerCode ys) : xs.count 0 = ys.count 0 := by
  have hxc : xs.count 0 < 16 := lt_of_le_of_lt List.count_le_length hx
  have hyc : ys.count 0 < 16 := lt_of_le_of_lt List.count_le_length hy
  rw [powerCode_split xs, powerCode_split ys] at h
  have hm := congrArg (· % 16) h
  simpa [Nat.add_mod, Nat.mul_mod, Nat.mod_eq_of_lt hxc, Nat.mod_eq_of_lt hyc] using hm

private theorem equal_lower_codes {xs ys : List Nat}
    (hx : xs.length < 16) (hy : ys.length < 16)
    (h : powerCode xs = powerCode ys) : powerCode (lower xs) = powerCode (lower ys) := by
  have hz := equal_zero_counts hx hy h
  rw [powerCode_split xs, powerCode_split ys, hz] at h
  exact Nat.mul_left_cancel (by decide) (Nat.add_left_cancel h)

/-- Fewer than sixteen entries prevent carries, so the encoding determines every count. -/
theorem powerCode_count {xs ys : List Nat}
    (hx : xs.length < 16) (hy : ys.length < 16)
    (h : powerCode xs = powerCode ys) (k : Nat) : xs.count k = ys.count k := by
  induction k generalizing xs ys with
  | zero => exact equal_zero_counts hx hy h
  | succ k ih =>
    have hh := ih (lt_of_le_of_lt (lower_length xs) hx)
      (lt_of_le_of_lt (lower_length ys) hy) (equal_lower_codes hx hy h)
    simpa only [count_lower] using hh

theorem powerCode_perm {xs ys : List Nat}
    (hx : xs.length < 16) (hy : ys.length < 16)
    (h : powerCode xs = powerCode ys) : xs.Perm ys :=
  List.perm_iff_count.mpr (powerCode_count hx hy h)

theorem powerCode_equal_members {xs ys : List Nat}
    (hx : xs.length < 16) (hy : ys.length < 16)
    (h : powerCode xs = powerCode ys) (k : Nat) : k ∈ xs ↔ k ∈ ys :=
  (powerCode_perm hx hy h).mem_iff

private theorem powerCode_div_base {xs : List Nat} (hx : xs.length < 16) :
    powerCode xs / 16 = powerCode (lower xs) := by
  have hc : xs.count 0 < 16 := lt_of_le_of_lt List.count_le_length hx
  have hs := powerCode_split xs
  omega

/-- A digit gives the exact multiplicity; the length bound rules out carries. -/
theorem powerCode_digit {xs : List Nat} (hx : xs.length < 16) (k : Nat) :
    (powerCode xs / 16 ^ k) % 16 = xs.count k := by
  induction k generalizing xs with
  | zero =>
      have hc : xs.count 0 < 16 := lt_of_le_of_lt List.count_le_length hx
      rw [pow_zero, Nat.div_one, powerCode_split xs]
      simp [Nat.add_mod, Nat.mul_mod, Nat.mod_eq_of_lt hc]
  | succ k ih =>
      rw [pow_succ', ← Nat.div_div_eq_div_mul, powerCode_div_base hx]
      simpa only [count_lower] using ih (lt_of_le_of_lt (lower_length xs) hx)

theorem powerCode_digit_pos_iff {xs : List Nat} (hx : xs.length < 16) (k : Nat) :
    0 < (powerCode xs / 16 ^ k) % 16 ↔ k ∈ xs := by
  rw [powerCode_digit hx]
  exact List.count_pos_iff

end LockedHeptomino.Encoding

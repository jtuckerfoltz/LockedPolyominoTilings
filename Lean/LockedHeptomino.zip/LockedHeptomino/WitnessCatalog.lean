import LockedHeptomino.Witness

namespace LockedHeptomino

/-- A balanced lookup catalog; branch thresholds refer to absolute indices. -/
inductive WitnessTree where
  | leaf (witness : SplitWitness)
  | node (threshold : Nat) (left right : WitnessTree)

def WitnessTree.get : WitnessTree → Nat → SplitWitness
  | .leaf witness, _ => witness
  | .node threshold left right, index =>
      if index < threshold then left.get index else right.get index

def WitnessTree.check : WitnessTree → Bool
  | .leaf witness => witness.check
  | .node _ left right => left.check && right.check

theorem WitnessTree.node_checked (threshold : Nat) (left right : WitnessTree)
    (hl : left.check = true) (hr : right.check = true) :
    (WitnessTree.node threshold left right).check = true := by
  simp only [WitnessTree.check, hl, hr, Bool.and_self]

/-- Bounds need not be trusted: every returned leaf has been checked. -/
theorem WitnessTree.get_checked (tree : WitnessTree) (h : tree.check = true)
    (index : Nat) : (tree.get index).check = true := by
  induction tree with
  | leaf witness => exact h
  | node threshold left right hl hr =>
      have hh : left.check = true ∧ right.check = true := by
        simpa only [WitnessTree.check, Bool.and_eq_true] using h
      simp only [WitnessTree.get]
      split
      · exact hl hh.1
      · exact hr hh.2

end LockedHeptomino

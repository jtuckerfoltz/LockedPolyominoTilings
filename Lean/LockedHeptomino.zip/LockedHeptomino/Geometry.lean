import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Union
import Mathlib.Logic.Relation
import LockedHeptomino.Prelude

/-!
# Grid geometry and complete rooted polyomino enumeration

Connectivity is ordinary edge-path connectivity inside a finite set of cells.
The enumeration starts with the origin and inserts one edge-neighbor at a time.
Its completeness is a theorem about arbitrary finite connected sets, rather
than an assumption about the data emitted by the external certificate producer.
-/

namespace LockedHeptomino

set_option maxRecDepth 4096

abbrev Cell := Int × Int

def origin : Cell := (0, 0)

def neighbors (p : Cell) : Finset Cell :=
  {(p.1 + 1, p.2), (p.1 - 1, p.2), (p.1, p.2 + 1), (p.1, p.2 - 1)}

/-- Sharing a unit grid edge. -/
def Adjacent (p q : Cell) : Prop := q ∈ neighbors p

instance (p q : Cell) : Decidable (Adjacent p q) :=
  inferInstanceAs (Decidable (q ∈ neighbors p))

theorem adjacent_iff (p q : Cell) :
    Adjacent p q ↔
      q = (p.1 + 1, p.2) ∨ q = (p.1 - 1, p.2) ∨
      q = (p.1, p.2 + 1) ∨ q = (p.1, p.2 - 1) := by
  simp [Adjacent, neighbors]

theorem adjacent_symm {p q : Cell} (h : Adjacent p q) : Adjacent q p := by
  rcases p with ⟨px, py⟩
  rcases q with ⟨qx, qy⟩
  simp only [adjacent_iff, Prod.mk.injEq] at h ⊢
  omega

theorem adjacent_irrefl (p : Cell) : ¬ Adjacent p p := by
  rcases p with ⟨px, py⟩
  simp only [adjacent_iff, Prod.mk.injEq]
  omega

/-- A step whose two endpoints belong to the specified cell set. -/
def StepIn (s : Finset Cell) (p q : Cell) : Prop :=
  p ∈ s ∧ q ∈ s ∧ Adjacent p q

/-- Nonempty, with an edge path inside the set between every two cells. -/
def Connected (s : Finset Cell) : Prop :=
  s.Nonempty ∧ ∀ p ∈ s, ∀ q ∈ s, Relation.ReflTransGen (StepIn s) p q

theorem connected_singleton (p : Cell) : Connected {p} := by
  constructor
  · exact ⟨p, Finset.mem_singleton_self p⟩
  · intro a ha b hb
    have ha' : a = p := Finset.mem_singleton.mp ha
    have hb' : b = p := Finset.mem_singleton.mp hb
    subst a
    subst b
    exact Relation.ReflTransGen.refl

theorem path_mono {s t : Finset Cell} (hst : s ⊆ t) {a b : Cell}
    (h : Relation.ReflTransGen (StepIn s) a b) :
    Relation.ReflTransGen (StepIn t) a b := by
  induction h with
  | refl => exact Relation.ReflTransGen.refl
  | tail _ hstep ih => exact ih.tail ⟨hst hstep.1, hst hstep.2.1, hstep.2.2⟩

theorem connected_insert {s : Finset Cell} (hs : Connected s)
    {a b : Cell} (ha : a ∈ s) (hab : Adjacent a b) : Connected (insert b s) := by
  have hsub : s ⊆ insert b s := Finset.subset_insert b s
  have hba : StepIn (insert b s) b a :=
    ⟨Finset.mem_insert_self b s, hsub ha, adjacent_symm hab⟩
  have hab' : StepIn (insert b s) a b :=
    ⟨hsub ha, Finset.mem_insert_self b s, hab⟩
  constructor
  · exact ⟨b, Finset.mem_insert_self b s⟩
  · intro p hp q hq
    rcases Finset.mem_insert.mp hp with hpb | hps
    · subst p
      rcases Finset.mem_insert.mp hq with hqb | hqs
      · subst q
        exact Relation.ReflTransGen.refl
      · exact (path_mono hsub (hs.2 a ha q hqs)).head hba
    · rcases Finset.mem_insert.mp hq with hqb | hqs
      · subst q
        exact (path_mono hsub (hs.2 p hps a ha)).tail hab'
      · exact path_mono hsub (hs.2 p hps q hqs)

/-- A path from inside a subset to outside it crosses its edge boundary. -/
theorem path_crosses_boundary {s t : Finset Cell} {a b : Cell}
    (ha : a ∈ s) (h : Relation.ReflTransGen (StepIn t) a b) (hb : b ∉ s) :
    ∃ p ∈ s, ∃ q ∈ t, q ∉ s ∧ Adjacent p q := by
  induction h with
  | refl => exact False.elim (hb ha)
  | @tail b c hpath hstep ih =>
      by_cases hbs : b ∈ s
      · exact ⟨b, hbs, c, hstep.2.1, hb, hstep.2.2⟩
      · exact ih hbs

theorem connected_boundary {s t : Finset Cell} (ht : Connected t)
    (hs : s.Nonempty) (hst : s ⊆ t) (hlt : s.card < t.card) :
    ∃ p ∈ s, ∃ q ∈ t, q ∉ s ∧ Adjacent p q := by
  obtain ⟨a, ha⟩ := hs
  obtain ⟨b, hbt, hbs⟩ := Finset.exists_mem_not_mem_of_card_lt_card hlt
  exact path_crosses_boundary ha (ht.2 a (hst ha) b hbt) hbs

/-- All sets obtained by adding exactly one new edge-neighbor. -/
def grow (s : Finset Cell) : Finset (Finset Cell) :=
  s.biUnion fun p => ((neighbors p) \ s).image fun q => insert q s

theorem mem_grow_iff {s t : Finset Cell} :
    t ∈ grow s ↔ ∃ p ∈ s, ∃ q, Adjacent p q ∧ q ∉ s ∧ insert q s = t := by
  simp only [grow, Finset.mem_biUnion, Finset.mem_image, Finset.mem_sdiff, Adjacent]
  aesop

/-- `rootedShapes n` enumerates rooted connected shapes with `n+1` cells. -/
def rootedShapes : Nat → Finset (Finset Cell)
  | 0 => {{origin}}
  | n + 1 => (rootedShapes n).biUnion grow

theorem rootedShapes_zero : rootedShapes 0 = {{origin}} := rfl

theorem rootedShapes_succ (n : Nat) :
    rootedShapes (n + 1) = (rootedShapes n).biUnion grow := rfl

attribute [irreducible] rootedShapes

theorem rootedShapes_sound {n : Nat} {s : Finset Cell} (h : s ∈ rootedShapes n) :
    origin ∈ s ∧ s.card = n + 1 ∧ Connected s := by
  induction n generalizing s with
  | zero =>
      rw [rootedShapes_zero] at h
      have hs : s = {origin} := Finset.mem_singleton.mp h
      subst s
      exact ⟨Finset.mem_singleton_self origin, by simp, connected_singleton origin⟩
  | succ n ih =>
      rw [rootedShapes_succ] at h
      obtain ⟨t, ht, hst⟩ := Finset.mem_biUnion.mp h
      obtain ⟨p, hp, q, hpq, hqt, rfl⟩ := mem_grow_iff.mp hst
      obtain ⟨horigin, hcard, hconn⟩ := ih ht
      refine ⟨Finset.mem_insert_of_mem horigin, ?_, connected_insert hconn hp hpq⟩
      rw [Finset.card_insert_of_not_mem hqt, hcard]

/-- Each initial segment size of a connected shape can be grown from its root. -/
theorem rootedShapes_subset_exists {s : Finset Cell} (hs : Connected s)
    (hroot : origin ∈ s) (n : Nat) (hn : n + 1 ≤ s.card) :
    ∃ t ∈ rootedShapes n, t ⊆ s := by
  induction n with
  | zero =>
      refine ⟨{origin}, ?_, Finset.singleton_subset_iff.mpr hroot⟩
      rw [rootedShapes_zero]
      exact Finset.mem_singleton_self _
  | succ n ih =>
      obtain ⟨t, ht, hts⟩ := ih (by omega)
      obtain ⟨hroot_t, hcard_t, _⟩ := rootedShapes_sound ht
      have hlt : t.card < s.card := by omega
      obtain ⟨p, hp, q, hqs, hqt, hpq⟩ :=
        connected_boundary hs ⟨origin, hroot_t⟩ hts hlt
      refine ⟨insert q t, ?_, ?_⟩
      · rw [rootedShapes_succ]
        exact Finset.mem_biUnion.mpr ⟨t, ht,
          mem_grow_iff.mpr ⟨p, hp, q, hpq, hqt, rfl⟩⟩
      · exact Finset.insert_subset hqs hts

/-- Completeness of growth enumeration for arbitrary rooted connected shapes. -/
theorem rootedShapes_complete {s : Finset Cell} (hs : Connected s)
    (hroot : origin ∈ s) {n : Nat} (hcard : s.card = n + 1) :
    s ∈ rootedShapes n := by
  obtain ⟨t, ht, hts⟩ := rootedShapes_subset_exists hs hroot n (by omega)
  have htc := (rootedShapes_sound ht).2.1
  have hts_eq : t = s := Finset.eq_of_subset_of_card_le hts (by omega)
  simpa [hts_eq] using ht

def rootedHeptominoes : Finset (Finset Cell) := rootedShapes 6

theorem rootedHeptominoes_complete {s : Finset Cell} (hs : Connected s)
    (hroot : origin ∈ s) (hcard : s.card = 7) : s ∈ rootedHeptominoes :=
  rootedShapes_complete (n := 6) hs hroot hcard

theorem rootedHeptominoes_sound {s : Finset Cell} (h : s ∈ rootedHeptominoes) :
    origin ∈ s ∧ s.card = 7 ∧ Connected s := rootedShapes_sound (n := 6) h

/-- A producer may certify its own, efficiently represented levels by checking
the base case and closure under every legal growth step.  This theorem avoids
ever reducing the deduplicating `Finset` enumeration in the kernel. -/
theorem rootedShapes_induction {P : Nat → Finset Cell → Prop}
    (hzero : P 0 {origin})
    (hstep : ∀ n s, P n s → ∀ p ∈ s, ∀ q,
      Adjacent p q → q ∉ s → P (n + 1) (insert q s))
    {n : Nat} {s : Finset Cell} (hs : s ∈ rootedShapes n) : P n s := by
  induction n generalizing s with
  | zero =>
      rw [rootedShapes_zero, Finset.mem_singleton] at hs
      simpa [hs] using hzero
  | succ n ih =>
      rw [rootedShapes_succ] at hs
      obtain ⟨t, ht, hst⟩ := Finset.mem_biUnion.mp hs
      obtain ⟨p, hp, q, hpq, hqt, rfl⟩ := mem_grow_iff.mp hst
      exact hstep n t (ih ht) p hp q hpq hqt

def shiftCell (v p : Cell) : Cell := (p.1 + v.1, p.2 + v.2)

def translate (v : Cell) (s : Finset Cell) : Finset Cell := s.image (shiftCell v)

theorem shiftCell_injective (v : Cell) : Function.Injective (shiftCell v) := by
  intro p q hpq
  rcases p with ⟨px, py⟩
  rcases q with ⟨qx, qy⟩
  simp only [shiftCell, Prod.mk.injEq] at hpq ⊢
  omega

@[simp] theorem translate_card (v : Cell) (s : Finset Cell) :
    (translate v s).card = s.card :=
  Finset.card_image_of_injective s (shiftCell_injective v)

theorem adjacent_shift {p q : Cell} (h : Adjacent p q) (v : Cell) :
    Adjacent (shiftCell v p) (shiftCell v q) := by
  rcases p with ⟨px, py⟩
  rcases q with ⟨qx, qy⟩
  rcases v with ⟨vx, vy⟩
  simp only [adjacent_iff, shiftCell, Prod.mk.injEq] at h ⊢
  omega

theorem path_translate {s : Finset Cell} {a b : Cell}
    (h : Relation.ReflTransGen (StepIn s) a b) (v : Cell) :
    Relation.ReflTransGen (StepIn (translate v s)) (shiftCell v a) (shiftCell v b) := by
  induction h with
  | refl => exact Relation.ReflTransGen.refl
  | tail _ hstep ih =>
      exact ih.tail ⟨Finset.mem_image_of_mem _ hstep.1,
        Finset.mem_image_of_mem _ hstep.2.1, adjacent_shift hstep.2.2 v⟩

theorem connected_translate {s : Finset Cell} (h : Connected s) (v : Cell) :
    Connected (translate v s) := by
  constructor
  · obtain ⟨p, hp⟩ := h.1
    exact ⟨shiftCell v p, Finset.mem_image_of_mem _ hp⟩
  · intro a ha b hb
    obtain ⟨a', ha', rfl⟩ := Finset.mem_image.mp ha
    obtain ⟨b', hb', rfl⟩ := Finset.mem_image.mp hb
    exact path_translate (h.2 a' ha' b' hb') v

def negCell (p : Cell) : Cell := (-p.1, -p.2)

@[simp] theorem shiftCell_neg_cancel (v p : Cell) :
    shiftCell (negCell v) (shiftCell v p) = p := by
  ext <;> simp [shiftCell, negCell]

@[simp] theorem shiftCell_cancel_neg (v p : Cell) :
    shiftCell v (shiftCell (negCell v) p) = p := by
  ext <;> simp [shiftCell, negCell]

@[simp] theorem translate_neg_cancel (v : Cell) (s : Finset Cell) :
    translate (negCell v) (translate v s) = s := by
  simp [translate, Finset.image_image, Function.comp_def]

@[simp] theorem translate_cancel_neg (v : Cell) (s : Finset Cell) :
    translate v (translate (negCell v) s) = s := by
  simp [translate, Finset.image_image, Function.comp_def]

theorem mem_translate_iff {v p : Cell} {s : Finset Cell} :
    p ∈ translate v s ↔ shiftCell (negCell v) p ∈ s := by
  constructor
  · intro hp
    obtain ⟨q, hq, rfl⟩ := Finset.mem_image.mp hp
    simpa using hq
  · intro hp
    apply Finset.mem_image.mpr
    exact ⟨shiftCell (negCell v) p, hp, shiftCell_cancel_neg v p⟩

theorem connected_translate_iff (v : Cell) (s : Finset Cell) :
    Connected (translate v s) ↔ Connected s := by
  constructor
  · intro h
    simpa using connected_translate h (negCell v)
  · exact fun h => connected_translate h v

/-- Root a tile at any of its cells; every such rooted heptomino is enumerated. -/
theorem rooted_translate_mem {s : Finset Cell} (hs : Connected s)
    (hcard : s.card = 7) {p : Cell} (hp : p ∈ s) :
    translate (negCell p) s ∈ rootedHeptominoes := by
  apply rootedHeptominoes_complete (connected_translate hs _)
  · apply Finset.mem_image.mpr
    exact ⟨p, hp, by simp [shiftCell, negCell, origin]⟩
  · simpa using hcard

/-- Interchanging the coordinate axes. -/
def transposeCell (p : Cell) : Cell := (p.2, p.1)

def transpose (s : Finset Cell) : Finset Cell := s.image transposeCell

@[simp] theorem transposeCell_transposeCell (p : Cell) :
    transposeCell (transposeCell p) = p := rfl

theorem transposeCell_injective : Function.Injective transposeCell := by
  intro p q h
  have := congrArg transposeCell h
  simpa using this

@[simp] theorem transpose_card (s : Finset Cell) : (transpose s).card = s.card :=
  Finset.card_image_of_injective s transposeCell_injective

@[simp] theorem transpose_transpose (s : Finset Cell) : transpose (transpose s) = s := by
  simp [transpose, Finset.image_image, Function.comp_def]

theorem adjacent_transpose {p q : Cell} (h : Adjacent p q) :
    Adjacent (transposeCell p) (transposeCell q) := by
  rcases p with ⟨px, py⟩
  rcases q with ⟨qx, qy⟩
  simp only [adjacent_iff, transposeCell, Prod.mk.injEq] at h ⊢
  omega

theorem path_transpose {s : Finset Cell} {a b : Cell}
    (h : Relation.ReflTransGen (StepIn s) a b) :
    Relation.ReflTransGen (StepIn (transpose s)) (transposeCell a) (transposeCell b) := by
  induction h with
  | refl => exact Relation.ReflTransGen.refl
  | tail _ hstep ih =>
      exact ih.tail ⟨Finset.mem_image_of_mem _ hstep.1,
        Finset.mem_image_of_mem _ hstep.2.1, adjacent_transpose hstep.2.2⟩

theorem connected_transpose {s : Finset Cell} (h : Connected s) : Connected (transpose s) := by
  constructor
  · obtain ⟨p, hp⟩ := h.1
    exact ⟨transposeCell p, Finset.mem_image_of_mem _ hp⟩
  · intro a ha b hb
    obtain ⟨a', ha', rfl⟩ := Finset.mem_image.mp ha
    obtain ⟨b', hb', rfl⟩ := Finset.mem_image.mp hb
    exact path_transpose (h.2 a' ha' b' hb')

theorem connected_transpose_iff (s : Finset Cell) : Connected (transpose s) ↔ Connected s := by
  constructor
  · intro h
    simpa using connected_transpose h
  · exact connected_transpose

theorem mem_transpose_iff {p : Cell} {s : Finset Cell} :
    p ∈ transpose s ↔ transposeCell p ∈ s := by
  constructor
  · intro hp
    obtain ⟨q, hq, rfl⟩ := Finset.mem_image.mp hp
    simpa using hq
  · intro hp
    exact Finset.mem_image.mpr ⟨transposeCell p, hp, transposeCell_transposeCell p⟩

end LockedHeptomino

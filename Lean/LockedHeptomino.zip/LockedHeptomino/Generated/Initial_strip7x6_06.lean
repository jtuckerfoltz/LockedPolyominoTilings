import LockedHeptomino.InitialCheck
import LockedHeptomino.Generated.EnumerationData
import LockedHeptomino.Generated.InitialDomains
namespace LockedHeptomino.Generated
set_option maxRecDepth 100000
set_option maxHeartbeats 0
 theorem strip7x6_cell_6_checked :
    initialCellCheck (fun v => ((levels 6).lookup v).cells) 6 true
      6 (InitialDomains.strip7x6 ⟨6,by decide⟩) = true := by decide +kernel
end LockedHeptomino.Generated

import LockedHeptomino.InitialCheck
import LockedHeptomino.Generated.EnumerationData
import LockedHeptomino.Generated.InitialDomains
namespace LockedHeptomino.Generated
set_option maxRecDepth 100000
set_option maxHeartbeats 0
 theorem quadrant7x7_cell_6_checked :
    initialCellCheck (fun v => ((levels 6).lookup v).cells) 7 false
      6 (InitialDomains.quadrant7x7 ⟨6,by decide⟩) = true := by decide +kernel
end LockedHeptomino.Generated

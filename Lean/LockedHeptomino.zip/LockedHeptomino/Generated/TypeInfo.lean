import LockedHeptomino.Generated.TypeOrientation0
import LockedHeptomino.Generated.TypeOrientation1
import LockedHeptomino.Generated.TypeOrientation2
import LockedHeptomino.Generated.TypeOrientation3
import LockedHeptomino.Generated.TypeOrientation4
import LockedHeptomino.Generated.TypeOrientation5
import LockedHeptomino.Generated.TypeOrientation6
import LockedHeptomino.Generated.TypeOrientation7

namespace LockedHeptomino.Generated
open LockedHeptomino.Encoding

def typeInfoTree (orientation : Nat) : LookupTree TypeCodeInfo :=
  match orientation with
  | 0 => typeInfoTree0
  | 1 => typeInfoTree1
  | 2 => typeInfoTree2
  | 3 => typeInfoTree3
  | 4 => typeInfoTree4
  | 5 => typeInfoTree5
  | 6 => typeInfoTree6
  | _ => typeInfoTree7

theorem typeInfoTree_checked (orientation : Nat) (ho : orientation < 8) :
    checkTypeTree orientation level6 (typeInfoTree orientation) = true := by
  interval_cases orientation
  · exact typeInfoTree0_checked
  · exact typeInfoTree1_checked
  · exact typeInfoTree2_checked
  · exact typeInfoTree3_checked
  · exact typeInfoTree4_checked
  · exact typeInfoTree5_checked
  · exact typeInfoTree6_checked
  · exact typeInfoTree7_checked

def typeInfo (orientation index : Nat) : TypeCodeInfo := (typeInfoTree orientation).lookup index

theorem typeInfo_checked (orientation : Nat) (ho : orientation < 8) (index : Nat) :
    checkTypeInfo (orientedCells orientation index) (typeInfo orientation index) = true :=
  checkTypeTree_sound orientation level6 (typeInfoTree orientation) (typeInfoTree_checked orientation ho) index

end LockedHeptomino.Generated

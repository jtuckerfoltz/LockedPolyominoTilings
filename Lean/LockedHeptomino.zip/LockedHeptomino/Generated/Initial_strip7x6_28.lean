import LockedHeptomino.InitialCheck
import LockedHeptomino.Generated.EnumerationData
import LockedHeptomino.Generated.InitialDomains
namespace LockedHeptomino.Generated
set_option maxRecDepth 100000
set_option maxHeartbeats 0
 theorem strip7x6_cell_28_checked :
    initialCellCheck (fun v => ((levels 6).lookup v).cells) 6 true
      28 (InitialDomains.strip7x6 ⟨28,by decide⟩) = true := by decide +kernel
end LockedHeptomino.Generated

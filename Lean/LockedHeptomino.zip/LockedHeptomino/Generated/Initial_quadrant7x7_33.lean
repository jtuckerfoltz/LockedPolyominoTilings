import LockedHeptomino.InitialCheck
import LockedHeptomino.Generated.EnumerationData
import LockedHeptomino.Generated.InitialDomains
namespace LockedHeptomino.Generated
set_option maxRecDepth 100000
set_option maxHeartbeats 0
 theorem quadrant7x7_cell_33_checked :
    initialCellCheck (fun v => ((levels 6).lookup v).cells) 7 false
      33 (InitialDomains.quadrant7x7 ⟨33,by decide⟩) = true := by decide +kernel
end LockedHeptomino.Generated

import LockedHeptomino.Generated.IncidenceData
namespace LockedHeptomino.Generated
set_option maxRecDepth 8192
set_option maxHeartbeats 0
theorem incidenceLeaf128_checked : incidenceLeaf128.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf129_checked : incidenceLeaf129.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf130_checked : incidenceLeaf130.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf131_checked : incidenceLeaf131.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf132_checked : incidenceLeaf132.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf133_checked : incidenceLeaf133.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf134_checked : incidenceLeaf134.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf135_checked : incidenceLeaf135.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf136_checked : incidenceLeaf136.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf137_checked : incidenceLeaf137.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf138_checked : incidenceLeaf138.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf139_checked : incidenceLeaf139.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf140_checked : incidenceLeaf140.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf141_checked : incidenceLeaf141.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf142_checked : incidenceLeaf142.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf143_checked : incidenceLeaf143.all (IncidenceEntry.check typeShape) = true := by decide
end LockedHeptomino.Generated

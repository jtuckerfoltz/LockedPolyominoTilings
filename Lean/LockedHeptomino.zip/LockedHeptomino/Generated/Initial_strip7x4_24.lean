import LockedHeptomino.InitialCheck
import LockedHeptomino.Generated.EnumerationData
import LockedHeptomino.Generated.InitialDomains
namespace LockedHeptomino.Generated
set_option maxRecDepth 100000
set_option maxHeartbeats 0
 theorem strip7x4_cell_24_checked :
    initialCellCheck (fun v => ((levels 6).lookup v).cells) 4 true
      24 (InitialDomains.strip7x4 ⟨24,by decide⟩) = true := by decide +kernel
end LockedHeptomino.Generated

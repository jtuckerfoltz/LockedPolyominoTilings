import LockedHeptomino.InitialCheck
import LockedHeptomino.Generated.EnumerationData
import LockedHeptomino.Generated.InitialDomains
namespace LockedHeptomino.Generated
set_option maxRecDepth 100000
set_option maxHeartbeats 0
 theorem strip7x5_cell_4_checked :
    initialCellCheck (fun v => ((levels 6).lookup v).cells) 5 true
      4 (InitialDomains.strip7x5 ⟨4,by decide⟩) = true := by decide +kernel
end LockedHeptomino.Generated

import LockedHeptomino.InitialCheck
import LockedHeptomino.Generated.EnumerationData
import LockedHeptomino.Generated.InitialDomains
namespace LockedHeptomino.Generated
set_option maxRecDepth 100000
set_option maxHeartbeats 0
 theorem strip7x3_cell_1_checked :
    initialCellCheck (fun v => ((levels 6).lookup v).cells) 3 true
      1 (InitialDomains.strip7x3 ⟨1,by decide⟩) = true := by decide +kernel
end LockedHeptomino.Generated

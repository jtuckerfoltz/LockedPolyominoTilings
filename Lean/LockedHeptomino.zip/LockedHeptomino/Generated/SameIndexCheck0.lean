import LockedHeptomino.Generated.SameIndexData
namespace LockedHeptomino.Generated
set_option maxRecDepth 16384
set_option maxHeartbeats 0
theorem sameDirection0_checked : sameDirectionCheck typeShape sameIndex 0 = true := by decide
end LockedHeptomino.Generated

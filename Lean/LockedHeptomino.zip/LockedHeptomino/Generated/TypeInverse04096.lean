import LockedHeptomino.Generated.TypeOrientation0
import LockedHeptomino.Generated.TypeCodeIndexData

namespace LockedHeptomino.Generated.TypeInverse04096
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem checked : (List.range' 4096 256).all
    (fun i => typeCodeIndex (typeInfoTree0.lookup i).code == i) = true := by decide

end LockedHeptomino.Generated.TypeInverse04096

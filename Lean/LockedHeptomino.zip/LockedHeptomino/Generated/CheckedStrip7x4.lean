import LockedHeptomino.Generated.CheckedStrip7x4Data
import LockedHeptomino.Generated.ChecksStrip7x4.Chunk0000
import LockedHeptomino.Generated.ChecksStrip7x4.Chunk0001
import LockedHeptomino.Generated.ChecksStrip7x4.Chunk0002
import LockedHeptomino.Generated.ChecksStrip7x4.Chunk0003
import LockedHeptomino.Generated.ChecksStrip7x4.Chunk0004
namespace LockedHeptomino.Generated.CheckedStrip7x4
open LockedHeptomino.CSP
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem node0Empty : node0Exit 6 = 0 := by decide +kernel
theorem node0Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node0Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 28) (finRange_covers 28) chunk0Steps chunk0Before chunk0After chunk0Checked assignment hvalid hfit
  have h1 := verifyTransition_sound hsound (List.finRange 28) (finRange_covers 28) chunk1Steps chunk1Before chunk1After chunk1Checked assignment hvalid h0
  have h2 := verifyTransition_sound hsound (List.finRange 28) (finRange_covers 28) chunk2Steps chunk2Before chunk2After chunk2Checked assignment hvalid h1
  have h3 := verifyTransition_sound hsound (List.finRange 28) (finRange_covers 28) chunk3Steps chunk3Before chunk3After chunk3Checked assignment hvalid h2
  have h4 := verifyTransition_sound hsound (List.finRange 28) (finRange_covers 28) chunk4Steps chunk4Before chunk4After chunk4Checked assignment hvalid h3
  have hfinal : Fits node0Exit assignment := h4
  have hf := hfinal 6
  simp only [node0Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem no_assignment {valid : Assignment Cell → Prop}
    (hsound : TableSound valid table) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits initial assignment) : False :=
  node0Unsat (treeExcludes_sound hsound 13) assignment hvalid hfit
#print axioms no_assignment
end LockedHeptomino.Generated.CheckedStrip7x4

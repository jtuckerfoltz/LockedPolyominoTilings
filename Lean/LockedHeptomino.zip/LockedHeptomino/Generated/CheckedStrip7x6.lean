import LockedHeptomino.Generated.CheckedStrip7x6Data
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0000
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0001
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0002
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0003
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0004
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0005
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0006
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0007
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0008
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0009
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0010
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0011
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0012
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0013
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0014
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0015
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0016
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0017
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0018
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0019
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0020
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0021
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0022
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0023
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0024
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0025
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0026
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0027
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0028
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0029
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0030
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0031
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0032
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0033
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0034
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0035
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0036
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0037
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0038
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0039
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0040
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0041
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0042
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0043
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0044
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0045
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0046
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0047
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0048
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0049
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0050
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0051
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0052
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0053
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0054
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0055
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0056
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0057
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0058
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0059
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0060
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0061
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0062
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0063
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0064
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0065
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0066
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0067
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0068
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0069
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0070
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0071
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0072
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0073
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0074
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0075
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0076
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0077
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0078
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0079
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0080
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0081
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0082
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0083
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0084
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0085
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0086
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0087
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0088
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0089
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0090
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0091
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0092
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0093
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0094
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0095
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0096
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0097
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0098
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0099
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0100
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0101
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0102
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0103
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0104
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0105
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0106
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0107
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0108
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0109
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0110
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0111
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0112
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0113
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0114
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0115
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0116
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0117
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0118
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0119
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0120
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0121
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0122
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0123
import LockedHeptomino.Generated.ChecksStrip7x6.Chunk0124
namespace LockedHeptomino.Generated.CheckedStrip7x6
open LockedHeptomino.CSP
set_option maxRecDepth 100000
set_option maxHeartbeats 0
theorem node0Cover : subset (node0Exit 0) (bits [4561, 4562, 4563, 4564, 4565, 4566, 4568, 4569, 4570, 4572, 4573, 4574, 4577, 4590, 4591, 4592, 4594, 4602, 4603, 4605, 4614, 4644, 4645, 4646, 4647, 4649, 4650, 4656, 4673, 4676, 4677, 4682, 4701, 4773, 4775, 4776, 4778, 4780, 4786, 4787, 4788, 4790, 4791, 4794, 4796, 4818, 4819, 4827, 4828, 4830, 4831, 4844, 4856, 4857, 4859, 4860, 4878, 4879, 4883, 4884, 4889, 4891, 5121, 5130, 5143, 5144, 5146, 5147, 5163, 5164, 5165, 5166, 5168, 5169, 5170, 5177, 5178, 5180, 5181, 5184, 5185, 5189, 5190, 5195, 5197, 5275, 5276, 5278, 5279, 5284, 5306, 5307, 5308, 5314, 5315, 5316, 5318, 5319]) = true := by decide +kernel
theorem node1Empty : node1Exit 10 = 0 := by decide +kernel
theorem node2Empty : node2Exit 10 = 0 := by decide +kernel
theorem node3Empty : node3Exit 15 = 0 := by decide +kernel
theorem node4Empty : node4Exit 16 = 0 := by decide +kernel
theorem node5Empty : node5Exit 9 = 0 := by decide +kernel
theorem node6Empty : node6Exit 10 = 0 := by decide +kernel
theorem node7Empty : node7Exit 8 = 0 := by decide +kernel
theorem node8Empty : node8Exit 15 = 0 := by decide +kernel
theorem node9Empty : node9Exit 15 = 0 := by decide +kernel
theorem node10Empty : node10Exit 16 = 0 := by decide +kernel
theorem node11Empty : node11Exit 15 = 0 := by decide +kernel
theorem node12Empty : node12Exit 15 = 0 := by decide +kernel
theorem node13Empty : node13Exit 16 = 0 := by decide +kernel
theorem node14Empty : node14Exit 15 = 0 := by decide +kernel
theorem node15Empty : node15Exit 16 = 0 := by decide +kernel
theorem node16Empty : node16Exit 15 = 0 := by decide +kernel
theorem node17Empty : node17Exit 15 = 0 := by decide +kernel
theorem node18Empty : node18Exit 7 = 0 := by decide +kernel
theorem node19Empty : node19Exit 16 = 0 := by decide +kernel
theorem node20Empty : node20Exit 10 = 0 := by decide +kernel
theorem node21Empty : node21Exit 14 = 0 := by decide +kernel
theorem node22Empty : node22Exit 16 = 0 := by decide +kernel
theorem node23Empty : node23Exit 16 = 0 := by decide +kernel
theorem node24Empty : node24Exit 16 = 0 := by decide +kernel
theorem node25Empty : node25Exit 9 = 0 := by decide +kernel
theorem node26Empty : node26Exit 16 = 0 := by decide +kernel
theorem node27Empty : node27Exit 14 = 0 := by decide +kernel
theorem node28Empty : node28Exit 14 = 0 := by decide +kernel
theorem node29Empty : node29Exit 17 = 0 := by decide +kernel
theorem node30Empty : node30Exit 10 = 0 := by decide +kernel
theorem node31Empty : node31Exit 14 = 0 := by decide +kernel
theorem node32Empty : node32Exit 13 = 0 := by decide +kernel
theorem node33Empty : node33Exit 14 = 0 := by decide +kernel
theorem node34Empty : node34Exit 10 = 0 := by decide +kernel
theorem node35Empty : node35Exit 14 = 0 := by decide +kernel
theorem node36Empty : node36Exit 21 = 0 := by decide +kernel
theorem node37Empty : node37Exit 9 = 0 := by decide +kernel
theorem node38Empty : node38Exit 9 = 0 := by decide +kernel
theorem node39Empty : node39Exit 8 = 0 := by decide +kernel
theorem node40Empty : node40Exit 10 = 0 := by decide +kernel
theorem node41Empty : node41Exit 10 = 0 := by decide +kernel
theorem node42Empty : node42Exit 14 = 0 := by decide +kernel
theorem node43Empty : node43Exit 8 = 0 := by decide +kernel
theorem node44Empty : node44Exit 8 = 0 := by decide +kernel
theorem node45Empty : node45Exit 8 = 0 := by decide +kernel
theorem node46Empty : node46Exit 14 = 0 := by decide +kernel
theorem node47Empty : node47Exit 14 = 0 := by decide +kernel
theorem node48Empty : node48Exit 13 = 0 := by decide +kernel
theorem node49Empty : node49Exit 15 = 0 := by decide +kernel
theorem node50Empty : node50Exit 19 = 0 := by decide +kernel
theorem node51Empty : node51Exit 8 = 0 := by decide +kernel
theorem node52Empty : node52Exit 10 = 0 := by decide +kernel
theorem node53Empty : node53Exit 13 = 0 := by decide +kernel
theorem node54Empty : node54Exit 9 = 0 := by decide +kernel
theorem node55Empty : node55Exit 13 = 0 := by decide +kernel
theorem node56Empty : node56Exit 13 = 0 := by decide +kernel
theorem node57Empty : node57Exit 15 = 0 := by decide +kernel
theorem node58Empty : node58Exit 15 = 0 := by decide +kernel
theorem node59Empty : node59Exit 15 = 0 := by decide +kernel
theorem node60Empty : node60Exit 19 = 0 := by decide +kernel
theorem node61Empty : node61Exit 14 = 0 := by decide +kernel
theorem node62Empty : node62Exit 14 = 0 := by decide +kernel
theorem node63Empty : node63Exit 10 = 0 := by decide +kernel
theorem node64Empty : node64Exit 9 = 0 := by decide +kernel
theorem node65Empty : node65Exit 9 = 0 := by decide +kernel
theorem node66Empty : node66Exit 9 = 0 := by decide +kernel
theorem node67Empty : node67Exit 9 = 0 := by decide +kernel
theorem node68Empty : node68Exit 9 = 0 := by decide +kernel
theorem node69Empty : node69Exit 8 = 0 := by decide +kernel
theorem node70Empty : node70Exit 8 = 0 := by decide +kernel
theorem node71Empty : node71Exit 8 = 0 := by decide +kernel
theorem node72Empty : node72Exit 8 = 0 := by decide +kernel
theorem node73Empty : node73Exit 14 = 0 := by decide +kernel
theorem node74Empty : node74Exit 20 = 0 := by decide +kernel
theorem node75Empty : node75Exit 8 = 0 := by decide +kernel
theorem node76Empty : node76Exit 14 = 0 := by decide +kernel
theorem node77Empty : node77Exit 14 = 0 := by decide +kernel
theorem node78Empty : node78Exit 14 = 0 := by decide +kernel
theorem node79Empty : node79Exit 8 = 0 := by decide +kernel
theorem node80Empty : node80Exit 8 = 0 := by decide +kernel
theorem node81Empty : node81Exit 8 = 0 := by decide +kernel
theorem node82Empty : node82Exit 8 = 0 := by decide +kernel
theorem node83Empty : node83Exit 8 = 0 := by decide +kernel
theorem node84Empty : node84Exit 8 = 0 := by decide +kernel
theorem node85Empty : node85Exit 8 = 0 := by decide +kernel
theorem node86Empty : node86Exit 14 = 0 := by decide +kernel
theorem node87Empty : node87Exit 14 = 0 := by decide +kernel
theorem node88Empty : node88Exit 14 = 0 := by decide +kernel
theorem node89Empty : node89Exit 14 = 0 := by decide +kernel
theorem node90Empty : node90Exit 9 = 0 := by decide +kernel
theorem node91Empty : node91Exit 13 = 0 := by decide +kernel
theorem node92Empty : node92Exit 13 = 0 := by decide +kernel
theorem node93Empty : node93Exit 9 = 0 := by decide +kernel
theorem node94Empty : node94Exit 9 = 0 := by decide +kernel
theorem node95Empty : node95Exit 7 = 0 := by decide +kernel
theorem node96Empty : node96Exit 7 = 0 := by decide +kernel
theorem node97Empty : node97Exit 15 = 0 := by decide +kernel
theorem node98Empty : node98Exit 16 = 0 := by decide +kernel
theorem node98Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node98Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk123Steps chunk123Before chunk123After chunk123Checked assignment hvalid hfit
  have h1 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk124Steps chunk124Before chunk124After chunk124Checked assignment hvalid h0
  have hfinal : Fits node98Exit assignment := h1
  have hf := hfinal 16
  simp only [node98Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node97Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node97Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk121Steps chunk121Before chunk121After chunk121Checked assignment hvalid hfit
  have h1 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk122Steps chunk122Before chunk122After chunk122Checked assignment hvalid h0
  have hfinal : Fits node97Exit assignment := h1
  have hf := hfinal 15
  simp only [node97Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node96Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node96Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk120Steps chunk120Before chunk120After chunk120Checked assignment hvalid hfit
  have hfinal : Fits node96Exit assignment := h0
  have hf := hfinal 7
  simp only [node96Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node95Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node95Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk119Steps chunk119Before chunk119After chunk119Checked assignment hvalid hfit
  have hfinal : Fits node95Exit assignment := h0
  have hf := hfinal 7
  simp only [node95Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node94Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node94Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk118Steps chunk118Before chunk118After chunk118Checked assignment hvalid hfit
  have hfinal : Fits node94Exit assignment := h0
  have hf := hfinal 9
  simp only [node94Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node93Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node93Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk117Steps chunk117Before chunk117After chunk117Checked assignment hvalid hfit
  have hfinal : Fits node93Exit assignment := h0
  have hf := hfinal 9
  simp only [node93Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node92Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node92Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk116Steps chunk116Before chunk116After chunk116Checked assignment hvalid hfit
  have hfinal : Fits node92Exit assignment := h0
  have hf := hfinal 13
  simp only [node92Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node91Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node91Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk115Steps chunk115Before chunk115After chunk115Checked assignment hvalid hfit
  have hfinal : Fits node91Exit assignment := h0
  have hf := hfinal 13
  simp only [node91Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node90Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node90Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk114Steps chunk114Before chunk114After chunk114Checked assignment hvalid hfit
  have hfinal : Fits node90Exit assignment := h0
  have hf := hfinal 9
  simp only [node90Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node89Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node89Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk113Steps chunk113Before chunk113After chunk113Checked assignment hvalid hfit
  have hfinal : Fits node89Exit assignment := h0
  have hf := hfinal 14
  simp only [node89Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node88Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node88Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk112Steps chunk112Before chunk112After chunk112Checked assignment hvalid hfit
  have hfinal : Fits node88Exit assignment := h0
  have hf := hfinal 14
  simp only [node88Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node87Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node87Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk111Steps chunk111Before chunk111After chunk111Checked assignment hvalid hfit
  have hfinal : Fits node87Exit assignment := h0
  have hf := hfinal 14
  simp only [node87Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node86Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node86Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk110Steps chunk110Before chunk110After chunk110Checked assignment hvalid hfit
  have hfinal : Fits node86Exit assignment := h0
  have hf := hfinal 14
  simp only [node86Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node85Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node85Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk109Steps chunk109Before chunk109After chunk109Checked assignment hvalid hfit
  have hfinal : Fits node85Exit assignment := h0
  have hf := hfinal 8
  simp only [node85Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node84Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node84Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk108Steps chunk108Before chunk108After chunk108Checked assignment hvalid hfit
  have hfinal : Fits node84Exit assignment := h0
  have hf := hfinal 8
  simp only [node84Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node83Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node83Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk107Steps chunk107Before chunk107After chunk107Checked assignment hvalid hfit
  have hfinal : Fits node83Exit assignment := h0
  have hf := hfinal 8
  simp only [node83Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node82Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node82Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk106Steps chunk106Before chunk106After chunk106Checked assignment hvalid hfit
  have hfinal : Fits node82Exit assignment := h0
  have hf := hfinal 8
  simp only [node82Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node81Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node81Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk105Steps chunk105Before chunk105After chunk105Checked assignment hvalid hfit
  have hfinal : Fits node81Exit assignment := h0
  have hf := hfinal 8
  simp only [node81Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node80Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node80Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk104Steps chunk104Before chunk104After chunk104Checked assignment hvalid hfit
  have hfinal : Fits node80Exit assignment := h0
  have hf := hfinal 8
  simp only [node80Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node79Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node79Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk103Steps chunk103Before chunk103After chunk103Checked assignment hvalid hfit
  have hfinal : Fits node79Exit assignment := h0
  have hf := hfinal 8
  simp only [node79Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node78Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node78Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk102Steps chunk102Before chunk102After chunk102Checked assignment hvalid hfit
  have hfinal : Fits node78Exit assignment := h0
  have hf := hfinal 14
  simp only [node78Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node77Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node77Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk101Steps chunk101Before chunk101After chunk101Checked assignment hvalid hfit
  have hfinal : Fits node77Exit assignment := h0
  have hf := hfinal 14
  simp only [node77Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node76Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node76Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk100Steps chunk100Before chunk100After chunk100Checked assignment hvalid hfit
  have hfinal : Fits node76Exit assignment := h0
  have hf := hfinal 14
  simp only [node76Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node75Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node75Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk99Steps chunk99Before chunk99After chunk99Checked assignment hvalid hfit
  have hfinal : Fits node75Exit assignment := h0
  have hf := hfinal 8
  simp only [node75Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node74Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node74Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk98Steps chunk98Before chunk98After chunk98Checked assignment hvalid hfit
  have hfinal : Fits node74Exit assignment := h0
  have hf := hfinal 20
  simp only [node74Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node73Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node73Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk97Steps chunk97Before chunk97After chunk97Checked assignment hvalid hfit
  have hfinal : Fits node73Exit assignment := h0
  have hf := hfinal 14
  simp only [node73Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node72Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node72Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk96Steps chunk96Before chunk96After chunk96Checked assignment hvalid hfit
  have hfinal : Fits node72Exit assignment := h0
  have hf := hfinal 8
  simp only [node72Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node71Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node71Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk95Steps chunk95Before chunk95After chunk95Checked assignment hvalid hfit
  have hfinal : Fits node71Exit assignment := h0
  have hf := hfinal 8
  simp only [node71Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node70Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node70Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk94Steps chunk94Before chunk94After chunk94Checked assignment hvalid hfit
  have hfinal : Fits node70Exit assignment := h0
  have hf := hfinal 8
  simp only [node70Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node69Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node69Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk93Steps chunk93Before chunk93After chunk93Checked assignment hvalid hfit
  have hfinal : Fits node69Exit assignment := h0
  have hf := hfinal 8
  simp only [node69Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node68Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node68Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk92Steps chunk92Before chunk92After chunk92Checked assignment hvalid hfit
  have hfinal : Fits node68Exit assignment := h0
  have hf := hfinal 9
  simp only [node68Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node67Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node67Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk91Steps chunk91Before chunk91After chunk91Checked assignment hvalid hfit
  have hfinal : Fits node67Exit assignment := h0
  have hf := hfinal 9
  simp only [node67Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node66Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node66Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk90Steps chunk90Before chunk90After chunk90Checked assignment hvalid hfit
  have hfinal : Fits node66Exit assignment := h0
  have hf := hfinal 9
  simp only [node66Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node65Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node65Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk89Steps chunk89Before chunk89After chunk89Checked assignment hvalid hfit
  have hfinal : Fits node65Exit assignment := h0
  have hf := hfinal 9
  simp only [node65Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node64Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node64Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk88Steps chunk88Before chunk88After chunk88Checked assignment hvalid hfit
  have hfinal : Fits node64Exit assignment := h0
  have hf := hfinal 9
  simp only [node64Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node63Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node63Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk87Steps chunk87Before chunk87After chunk87Checked assignment hvalid hfit
  have hfinal : Fits node63Exit assignment := h0
  have hf := hfinal 10
  simp only [node63Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node62Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node62Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk86Steps chunk86Before chunk86After chunk86Checked assignment hvalid hfit
  have hfinal : Fits node62Exit assignment := h0
  have hf := hfinal 14
  simp only [node62Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node61Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node61Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk85Steps chunk85Before chunk85After chunk85Checked assignment hvalid hfit
  have hfinal : Fits node61Exit assignment := h0
  have hf := hfinal 14
  simp only [node61Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node60Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node60Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk84Steps chunk84Before chunk84After chunk84Checked assignment hvalid hfit
  have hfinal : Fits node60Exit assignment := h0
  have hf := hfinal 19
  simp only [node60Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node59Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node59Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk83Steps chunk83Before chunk83After chunk83Checked assignment hvalid hfit
  have hfinal : Fits node59Exit assignment := h0
  have hf := hfinal 15
  simp only [node59Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node58Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node58Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk82Steps chunk82Before chunk82After chunk82Checked assignment hvalid hfit
  have hfinal : Fits node58Exit assignment := h0
  have hf := hfinal 15
  simp only [node58Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node57Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node57Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk81Steps chunk81Before chunk81After chunk81Checked assignment hvalid hfit
  have hfinal : Fits node57Exit assignment := h0
  have hf := hfinal 15
  simp only [node57Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node56Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node56Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk80Steps chunk80Before chunk80After chunk80Checked assignment hvalid hfit
  have hfinal : Fits node56Exit assignment := h0
  have hf := hfinal 13
  simp only [node56Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node55Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node55Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk79Steps chunk79Before chunk79After chunk79Checked assignment hvalid hfit
  have hfinal : Fits node55Exit assignment := h0
  have hf := hfinal 13
  simp only [node55Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node54Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node54Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk78Steps chunk78Before chunk78After chunk78Checked assignment hvalid hfit
  have hfinal : Fits node54Exit assignment := h0
  have hf := hfinal 9
  simp only [node54Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node53Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node53Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk77Steps chunk77Before chunk77After chunk77Checked assignment hvalid hfit
  have hfinal : Fits node53Exit assignment := h0
  have hf := hfinal 13
  simp only [node53Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node52Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node52Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk76Steps chunk76Before chunk76After chunk76Checked assignment hvalid hfit
  have hfinal : Fits node52Exit assignment := h0
  have hf := hfinal 10
  simp only [node52Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node51Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node51Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk74Steps chunk74Before chunk74After chunk74Checked assignment hvalid hfit
  have h1 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk75Steps chunk75Before chunk75After chunk75Checked assignment hvalid h0
  have hfinal : Fits node51Exit assignment := h1
  have hf := hfinal 8
  simp only [node51Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node50Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node50Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk73Steps chunk73Before chunk73After chunk73Checked assignment hvalid hfit
  have hfinal : Fits node50Exit assignment := h0
  have hf := hfinal 19
  simp only [node50Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node49Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node49Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk72Steps chunk72Before chunk72After chunk72Checked assignment hvalid hfit
  have hfinal : Fits node49Exit assignment := h0
  have hf := hfinal 15
  simp only [node49Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node48Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node48Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk71Steps chunk71Before chunk71After chunk71Checked assignment hvalid hfit
  have hfinal : Fits node48Exit assignment := h0
  have hf := hfinal 13
  simp only [node48Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node47Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node47Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk70Steps chunk70Before chunk70After chunk70Checked assignment hvalid hfit
  have hfinal : Fits node47Exit assignment := h0
  have hf := hfinal 14
  simp only [node47Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node46Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node46Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk69Steps chunk69Before chunk69After chunk69Checked assignment hvalid hfit
  have hfinal : Fits node46Exit assignment := h0
  have hf := hfinal 14
  simp only [node46Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node45Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node45Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk68Steps chunk68Before chunk68After chunk68Checked assignment hvalid hfit
  have hfinal : Fits node45Exit assignment := h0
  have hf := hfinal 8
  simp only [node45Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node44Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node44Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk67Steps chunk67Before chunk67After chunk67Checked assignment hvalid hfit
  have hfinal : Fits node44Exit assignment := h0
  have hf := hfinal 8
  simp only [node44Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node43Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node43Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk66Steps chunk66Before chunk66After chunk66Checked assignment hvalid hfit
  have hfinal : Fits node43Exit assignment := h0
  have hf := hfinal 8
  simp only [node43Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node42Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node42Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk65Steps chunk65Before chunk65After chunk65Checked assignment hvalid hfit
  have hfinal : Fits node42Exit assignment := h0
  have hf := hfinal 14
  simp only [node42Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node41Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node41Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk64Steps chunk64Before chunk64After chunk64Checked assignment hvalid hfit
  have hfinal : Fits node41Exit assignment := h0
  have hf := hfinal 10
  simp only [node41Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node40Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node40Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk63Steps chunk63Before chunk63After chunk63Checked assignment hvalid hfit
  have hfinal : Fits node40Exit assignment := h0
  have hf := hfinal 10
  simp only [node40Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node39Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node39Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk62Steps chunk62Before chunk62After chunk62Checked assignment hvalid hfit
  have hfinal : Fits node39Exit assignment := h0
  have hf := hfinal 8
  simp only [node39Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node38Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node38Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk61Steps chunk61Before chunk61After chunk61Checked assignment hvalid hfit
  have hfinal : Fits node38Exit assignment := h0
  have hf := hfinal 9
  simp only [node38Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node37Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node37Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk60Steps chunk60Before chunk60After chunk60Checked assignment hvalid hfit
  have hfinal : Fits node37Exit assignment := h0
  have hf := hfinal 9
  simp only [node37Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node36Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node36Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk59Steps chunk59Before chunk59After chunk59Checked assignment hvalid hfit
  have hfinal : Fits node36Exit assignment := h0
  have hf := hfinal 21
  simp only [node36Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node35Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node35Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk58Steps chunk58Before chunk58After chunk58Checked assignment hvalid hfit
  have hfinal : Fits node35Exit assignment := h0
  have hf := hfinal 14
  simp only [node35Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node34Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node34Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk57Steps chunk57Before chunk57After chunk57Checked assignment hvalid hfit
  have hfinal : Fits node34Exit assignment := h0
  have hf := hfinal 10
  simp only [node34Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node33Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node33Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk56Steps chunk56Before chunk56After chunk56Checked assignment hvalid hfit
  have hfinal : Fits node33Exit assignment := h0
  have hf := hfinal 14
  simp only [node33Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node32Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node32Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk55Steps chunk55Before chunk55After chunk55Checked assignment hvalid hfit
  have hfinal : Fits node32Exit assignment := h0
  have hf := hfinal 13
  simp only [node32Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node31Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node31Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk54Steps chunk54Before chunk54After chunk54Checked assignment hvalid hfit
  have hfinal : Fits node31Exit assignment := h0
  have hf := hfinal 14
  simp only [node31Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node30Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node30Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk53Steps chunk53Before chunk53After chunk53Checked assignment hvalid hfit
  have hfinal : Fits node30Exit assignment := h0
  have hf := hfinal 10
  simp only [node30Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node29Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node29Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk51Steps chunk51Before chunk51After chunk51Checked assignment hvalid hfit
  have h1 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk52Steps chunk52Before chunk52After chunk52Checked assignment hvalid h0
  have hfinal : Fits node29Exit assignment := h1
  have hf := hfinal 17
  simp only [node29Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node28Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node28Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk50Steps chunk50Before chunk50After chunk50Checked assignment hvalid hfit
  have hfinal : Fits node28Exit assignment := h0
  have hf := hfinal 14
  simp only [node28Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node27Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node27Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk49Steps chunk49Before chunk49After chunk49Checked assignment hvalid hfit
  have hfinal : Fits node27Exit assignment := h0
  have hf := hfinal 14
  simp only [node27Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node26Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node26Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk48Steps chunk48Before chunk48After chunk48Checked assignment hvalid hfit
  have hfinal : Fits node26Exit assignment := h0
  have hf := hfinal 16
  simp only [node26Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node25Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node25Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk47Steps chunk47Before chunk47After chunk47Checked assignment hvalid hfit
  have hfinal : Fits node25Exit assignment := h0
  have hf := hfinal 9
  simp only [node25Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node24Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node24Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk46Steps chunk46Before chunk46After chunk46Checked assignment hvalid hfit
  have hfinal : Fits node24Exit assignment := h0
  have hf := hfinal 16
  simp only [node24Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node23Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node23Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk45Steps chunk45Before chunk45After chunk45Checked assignment hvalid hfit
  have hfinal : Fits node23Exit assignment := h0
  have hf := hfinal 16
  simp only [node23Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node22Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node22Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk43Steps chunk43Before chunk43After chunk43Checked assignment hvalid hfit
  have h1 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk44Steps chunk44Before chunk44After chunk44Checked assignment hvalid h0
  have hfinal : Fits node22Exit assignment := h1
  have hf := hfinal 16
  simp only [node22Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node21Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node21Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk42Steps chunk42Before chunk42After chunk42Checked assignment hvalid hfit
  have hfinal : Fits node21Exit assignment := h0
  have hf := hfinal 14
  simp only [node21Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node20Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node20Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk41Steps chunk41Before chunk41After chunk41Checked assignment hvalid hfit
  have hfinal : Fits node20Exit assignment := h0
  have hf := hfinal 10
  simp only [node20Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node19Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node19Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk40Steps chunk40Before chunk40After chunk40Checked assignment hvalid hfit
  have hfinal : Fits node19Exit assignment := h0
  have hf := hfinal 16
  simp only [node19Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node18Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node18Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk39Steps chunk39Before chunk39After chunk39Checked assignment hvalid hfit
  have hfinal : Fits node18Exit assignment := h0
  have hf := hfinal 7
  simp only [node18Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node17Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node17Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk38Steps chunk38Before chunk38After chunk38Checked assignment hvalid hfit
  have hfinal : Fits node17Exit assignment := h0
  have hf := hfinal 15
  simp only [node17Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node16Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node16Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk37Steps chunk37Before chunk37After chunk37Checked assignment hvalid hfit
  have hfinal : Fits node16Exit assignment := h0
  have hf := hfinal 15
  simp only [node16Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node15Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node15Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk36Steps chunk36Before chunk36After chunk36Checked assignment hvalid hfit
  have hfinal : Fits node15Exit assignment := h0
  have hf := hfinal 16
  simp only [node15Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node14Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node14Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk35Steps chunk35Before chunk35After chunk35Checked assignment hvalid hfit
  have hfinal : Fits node14Exit assignment := h0
  have hf := hfinal 15
  simp only [node14Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node13Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node13Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk34Steps chunk34Before chunk34After chunk34Checked assignment hvalid hfit
  have hfinal : Fits node13Exit assignment := h0
  have hf := hfinal 16
  simp only [node13Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node12Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node12Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk33Steps chunk33Before chunk33After chunk33Checked assignment hvalid hfit
  have hfinal : Fits node12Exit assignment := h0
  have hf := hfinal 15
  simp only [node12Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node11Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node11Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk32Steps chunk32Before chunk32After chunk32Checked assignment hvalid hfit
  have hfinal : Fits node11Exit assignment := h0
  have hf := hfinal 15
  simp only [node11Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node10Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node10Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk31Steps chunk31Before chunk31After chunk31Checked assignment hvalid hfit
  have hfinal : Fits node10Exit assignment := h0
  have hf := hfinal 16
  simp only [node10Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node9Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node9Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk30Steps chunk30Before chunk30After chunk30Checked assignment hvalid hfit
  have hfinal : Fits node9Exit assignment := h0
  have hf := hfinal 15
  simp only [node9Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node8Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node8Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk29Steps chunk29Before chunk29After chunk29Checked assignment hvalid hfit
  have hfinal : Fits node8Exit assignment := h0
  have hf := hfinal 15
  simp only [node8Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node7Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node7Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk28Steps chunk28Before chunk28After chunk28Checked assignment hvalid hfit
  have hfinal : Fits node7Exit assignment := h0
  have hf := hfinal 8
  simp only [node7Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node6Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node6Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk27Steps chunk27Before chunk27After chunk27Checked assignment hvalid hfit
  have hfinal : Fits node6Exit assignment := h0
  have hf := hfinal 10
  simp only [node6Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node5Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node5Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk26Steps chunk26Before chunk26After chunk26Checked assignment hvalid hfit
  have hfinal : Fits node5Exit assignment := h0
  have hf := hfinal 9
  simp only [node5Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node4Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node4Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk25Steps chunk25Before chunk25After chunk25Checked assignment hvalid hfit
  have hfinal : Fits node4Exit assignment := h0
  have hf := hfinal 16
  simp only [node4Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node3Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node3Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk24Steps chunk24Before chunk24After chunk24Checked assignment hvalid hfit
  have hfinal : Fits node3Exit assignment := h0
  have hf := hfinal 15
  simp only [node3Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node2Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node2Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk23Steps chunk23Before chunk23After chunk23Checked assignment hvalid hfit
  have hfinal : Fits node2Exit assignment := h0
  have hf := hfinal 10
  simp only [node2Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node1Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node1Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk22Steps chunk22Before chunk22After chunk22Checked assignment hvalid hfit
  have hfinal : Fits node1Exit assignment := h0
  have hf := hfinal 10
  simp only [node1Empty, Nat.zero_testBit, Bool.false_eq_true] at hf

theorem node0Unsat {valid : Assignment Cell → Prop}
    (hsound : ExcludesSound valid oracle) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits node0Entry assignment) : False := by
  have h0 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk0Steps chunk0Before chunk0After chunk0Checked assignment hvalid hfit
  have h1 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk1Steps chunk1Before chunk1After chunk1Checked assignment hvalid h0
  have h2 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk2Steps chunk2Before chunk2After chunk2Checked assignment hvalid h1
  have h3 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk3Steps chunk3Before chunk3After chunk3Checked assignment hvalid h2
  have h4 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk4Steps chunk4Before chunk4After chunk4Checked assignment hvalid h3
  have h5 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk5Steps chunk5Before chunk5After chunk5Checked assignment hvalid h4
  have h6 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk6Steps chunk6Before chunk6After chunk6Checked assignment hvalid h5
  have h7 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk7Steps chunk7Before chunk7After chunk7Checked assignment hvalid h6
  have h8 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk8Steps chunk8Before chunk8After chunk8Checked assignment hvalid h7
  have h9 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk9Steps chunk9Before chunk9After chunk9Checked assignment hvalid h8
  have h10 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk10Steps chunk10Before chunk10After chunk10Checked assignment hvalid h9
  have h11 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk11Steps chunk11Before chunk11After chunk11Checked assignment hvalid h10
  have h12 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk12Steps chunk12Before chunk12After chunk12Checked assignment hvalid h11
  have h13 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk13Steps chunk13Before chunk13After chunk13Checked assignment hvalid h12
  have h14 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk14Steps chunk14Before chunk14After chunk14Checked assignment hvalid h13
  have h15 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk15Steps chunk15Before chunk15After chunk15Checked assignment hvalid h14
  have h16 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk16Steps chunk16Before chunk16After chunk16Checked assignment hvalid h15
  have h17 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk17Steps chunk17Before chunk17After chunk17Checked assignment hvalid h16
  have h18 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk18Steps chunk18Before chunk18After chunk18Checked assignment hvalid h17
  have h19 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk19Steps chunk19Before chunk19After chunk19Checked assignment hvalid h18
  have h20 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk20Steps chunk20Before chunk20After chunk20Checked assignment hvalid h19
  have h21 := verifyTransition_sound hsound (List.finRange 42) (finRange_covers 42) chunk21Steps chunk21Before chunk21After chunk21Checked assignment hvalid h20
  have hfinal : Fits node0Exit assignment := h21
  have hmem : assignment 0 ∈ [4561, 4562, 4563, 4564, 4565, 4566, 4568, 4569, 4570, 4572, 4573, 4574, 4577, 4590, 4591, 4592, 4594, 4602, 4603, 4605, 4614, 4644, 4645, 4646, 4647, 4649, 4650, 4656, 4673, 4676, 4677, 4682, 4701, 4773, 4775, 4776, 4778, 4780, 4786, 4787, 4788, 4790, 4791, 4794, 4796, 4818, 4819, 4827, 4828, 4830, 4831, 4844, 4856, 4857, 4859, 4860, 4878, 4879, 4883, 4884, 4889, 4891, 5121, 5130, 5143, 5144, 5146, 5147, 5163, 5164, 5165, 5166, 5168, 5169, 5170, 5177, 5178, 5180, 5181, 5184, 5185, 5189, 5190, 5195, 5197, 5275, 5276, 5278, 5279, 5284, 5306, 5307, 5308, 5314, 5315, 5316, 5318, 5319] := (bits_testBit _ _).mp (subset_sound node0Cover (hfinal 0))
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hmem
  rcases hmem with hv0 | hv1 | hv2 | hv3 | hv4 | hv5 | hv6 | hv7 | hv8 | hv9 | hv10 | hv11 | hv12 | hv13 | hv14 | hv15 | hv16 | hv17 | hv18 | hv19 | hv20 | hv21 | hv22 | hv23 | hv24 | hv25 | hv26 | hv27 | hv28 | hv29 | hv30 | hv31 | hv32 | hv33 | hv34 | hv35 | hv36 | hv37 | hv38 | hv39 | hv40 | hv41 | hv42 | hv43 | hv44 | hv45 | hv46 | hv47 | hv48 | hv49 | hv50 | hv51 | hv52 | hv53 | hv54 | hv55 | hv56 | hv57 | hv58 | hv59 | hv60 | hv61 | hv62 | hv63 | hv64 | hv65 | hv66 | hv67 | hv68 | hv69 | hv70 | hv71 | hv72 | hv73 | hv74 | hv75 | hv76 | hv77 | hv78 | hv79 | hv80 | hv81 | hv82 | hv83 | hv84 | hv85 | hv86 | hv87 | hv88 | hv89 | hv90 | hv91 | hv92 | hv93 | hv94 | hv95 | hv96 | hv97
  · apply node1Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv0]
  · apply node2Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv1]
  · apply node3Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv2]
  · apply node4Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv3]
  · apply node5Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv4]
  · apply node6Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv5]
  · apply node7Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv6]
  · apply node8Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv7]
  · apply node9Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv8]
  · apply node10Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv9]
  · apply node11Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv10]
  · apply node12Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv11]
  · apply node13Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv12]
  · apply node14Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv13]
  · apply node15Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv14]
  · apply node16Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv15]
  · apply node17Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv16]
  · apply node18Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv17]
  · apply node19Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv18]
  · apply node20Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv19]
  · apply node21Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv20]
  · apply node22Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv21]
  · apply node23Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv22]
  · apply node24Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv23]
  · apply node25Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv24]
  · apply node26Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv25]
  · apply node27Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv26]
  · apply node28Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv27]
  · apply node29Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv28]
  · apply node30Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv29]
  · apply node31Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv30]
  · apply node32Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv31]
  · apply node33Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv32]
  · apply node34Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv33]
  · apply node35Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv34]
  · apply node36Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv35]
  · apply node37Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv36]
  · apply node38Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv37]
  · apply node39Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv38]
  · apply node40Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv39]
  · apply node41Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv40]
  · apply node42Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv41]
  · apply node43Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv42]
  · apply node44Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv43]
  · apply node45Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv44]
  · apply node46Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv45]
  · apply node47Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv46]
  · apply node48Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv47]
  · apply node49Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv48]
  · apply node50Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv49]
  · apply node51Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv50]
  · apply node52Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv51]
  · apply node53Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv52]
  · apply node54Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv53]
  · apply node55Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv54]
  · apply node56Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv55]
  · apply node57Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv56]
  · apply node58Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv57]
  · apply node59Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv58]
  · apply node60Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv59]
  · apply node61Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv60]
  · apply node62Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv61]
  · apply node63Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv62]
  · apply node64Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv63]
  · apply node65Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv64]
  · apply node66Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv65]
  · apply node67Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv66]
  · apply node68Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv67]
  · apply node69Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv68]
  · apply node70Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv69]
  · apply node71Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv70]
  · apply node72Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv71]
  · apply node73Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv72]
  · apply node74Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv73]
  · apply node75Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv74]
  · apply node76Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv75]
  · apply node77Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv76]
  · apply node78Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv77]
  · apply node79Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv78]
  · apply node80Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv79]
  · apply node81Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv80]
  · apply node82Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv81]
  · apply node83Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv82]
  · apply node84Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv83]
  · apply node85Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv84]
  · apply node86Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv85]
  · apply node87Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv86]
  · apply node88Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv87]
  · apply node89Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv88]
  · apply node90Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv89]
  · apply node91Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv90]
  · apply node92Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv91]
  · apply node93Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv92]
  · apply node94Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv93]
  · apply node95Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv94]
  · apply node96Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv95]
  · apply node97Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv96]
  · apply node98Unsat hsound assignment hvalid
    apply replace_fits hfinal
    simp [Nat.testBit_two_pow, hv97]

theorem no_assignment {valid : Assignment Cell → Prop}
    (hsound : TableSound valid table) (assignment : Assignment Cell)
    (hvalid : valid assignment) (hfit : Fits initial assignment) : False :=
  node0Unsat (treeExcludes_sound hsound 13) assignment hvalid hfit
#print axioms no_assignment
end LockedHeptomino.Generated.CheckedStrip7x6

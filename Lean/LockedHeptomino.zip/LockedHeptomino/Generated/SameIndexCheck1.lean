import LockedHeptomino.Generated.SameIndexData
namespace LockedHeptomino.Generated
set_option maxRecDepth 16384
set_option maxHeartbeats 0
theorem sameDirection1_checked : sameDirectionCheck typeShape sameIndex 1 = true := by decide
end LockedHeptomino.Generated

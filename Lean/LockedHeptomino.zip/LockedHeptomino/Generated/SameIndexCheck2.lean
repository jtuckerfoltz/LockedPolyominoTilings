import LockedHeptomino.Generated.SameIndexData
namespace LockedHeptomino.Generated
set_option maxRecDepth 16384
set_option maxHeartbeats 0
theorem sameDirection2_checked : sameDirectionCheck typeShape sameIndex 2 = true := by decide
end LockedHeptomino.Generated

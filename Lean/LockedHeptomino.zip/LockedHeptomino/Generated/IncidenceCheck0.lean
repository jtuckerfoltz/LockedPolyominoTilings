import LockedHeptomino.Generated.IncidenceData
namespace LockedHeptomino.Generated
set_option maxRecDepth 8192
set_option maxHeartbeats 0
theorem incidenceLeaf0_checked : incidenceLeaf0.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf1_checked : incidenceLeaf1.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf2_checked : incidenceLeaf2.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf3_checked : incidenceLeaf3.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf4_checked : incidenceLeaf4.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf5_checked : incidenceLeaf5.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf6_checked : incidenceLeaf6.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf7_checked : incidenceLeaf7.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf8_checked : incidenceLeaf8.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf9_checked : incidenceLeaf9.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf10_checked : incidenceLeaf10.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf11_checked : incidenceLeaf11.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf12_checked : incidenceLeaf12.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf13_checked : incidenceLeaf13.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf14_checked : incidenceLeaf14.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf15_checked : incidenceLeaf15.all (IncidenceEntry.check typeShape) = true := by decide
end LockedHeptomino.Generated

import LockedHeptomino.Generated.IncidenceData
namespace LockedHeptomino.Generated
set_option maxRecDepth 8192
set_option maxHeartbeats 0
theorem incidenceLeaf160_checked : incidenceLeaf160.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf161_checked : incidenceLeaf161.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf162_checked : incidenceLeaf162.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf163_checked : incidenceLeaf163.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf164_checked : incidenceLeaf164.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf165_checked : incidenceLeaf165.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf166_checked : incidenceLeaf166.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf167_checked : incidenceLeaf167.all (IncidenceEntry.check typeShape) = true := by decide
theorem incidenceLeaf168_checked : incidenceLeaf168.all (IncidenceEntry.check typeShape) = true := by decide
end LockedHeptomino.Generated

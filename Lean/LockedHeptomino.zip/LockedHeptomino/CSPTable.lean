import LockedHeptomino.CSP

namespace LockedHeptomino.CSP

variable {α : Type} {n : Nat}

/-- A row encodes the values allowed at the second variable. -/
abbrev RelationTable (α : Type) := α → α → Nat → Nat

/--
Turn four directional relation tables into a rectangular-grid table.
Directions are east, south, west, north. Non-neighbors impose only the
universal value bound represented by `full`.
-/
def gridTable (width full : Nat) (rows : Nat → Nat → Nat) : RelationTable (Fin n) :=
  fun source target value =>
    if source.val / width = target.val / width ∧ source.val % width + 1 = target.val % width then
      rows 0 value
    else if source.val % width = target.val % width ∧ source.val / width + 1 = target.val / width then
      rows 1 value
    else if source.val / width = target.val / width ∧ target.val % width + 1 = source.val % width then
      rows 2 value
    else if source.val % width = target.val % width ∧ target.val / width + 1 = source.val / width then
      rows 3 value
    else full

/-- Tables may overapproximate compatibility; excluding any genuine pair is forbidden. -/
def TableSound (valid : Assignment α → Prop) (table : RelationTable α) : Prop :=
  ∀ assignment, valid assignment → ∀ source target,
    (table source target (assignment source)).testBit (assignment target) = true

/--
Only occupied bits cause relation-row checks. Division and remainder avoid
expanding a large shift operation while advancing through the bitset.
-/
def scanRows (row : Nat → Nat) (right : Nat) : Nat → Nat → Nat → Bool
  | 0, left, _ => left == 0
  | fuel + 1, left, offset =>
      if left == 0 then true else
        ((left % 2 == 0) || ((row offset &&& right) == 0)) &&
          scanRows row right fuel (left / 2) (offset + 1)

 theorem scanRows_sound {row : Nat → Nat} {right fuel left offset value : Nat}
    (hcheck : scanRows row right fuel left offset = true)
    (hbit : left.testBit value = true) : row (offset + value) &&& right = 0 := by
  induction fuel generalizing left offset value with
  | zero =>
      have hz : left = 0 := by simpa [scanRows] using hcheck
      simp [hz] at hbit
  | succ fuel ih =>
      by_cases hz : left = 0
      · simp [hz] at hbit
      · have hh : (left % 2 = 0 ∨ row offset &&& right = 0) ∧
            scanRows row right fuel (left / 2) (offset + 1) = true := by
          simpa [scanRows, hz, Bool.and_eq_true, Bool.or_eq_true] using hcheck
        cases value with
        | zero =>
            have ho : left % 2 = 1 := by simpa [Nat.testBit_zero] using hbit
            rcases hh.1 with he | he
            · omega
            · simpa using he
        | succ value =>
            have hb : (left / 2).testBit value = true := by
              simpa only [Nat.testBit_succ] using hbit
            have result := ih hh.2 hb
            simpa [Nat.add_assoc, Nat.add_comm 1 value] using result

/-- Binary subdivision skips entire zero blocks using kernel arithmetic. -/
def checkMask (predicate : Nat → Bool) : Nat → Nat → Nat → Bool
  | 0, left, offset => left == 0 || (left == 1 && predicate offset)
  | depth + 1, left, offset =>
      if left == 0 then true else
        let half := 2 ^ depth
        let divisor := 2 ^ half
        checkMask predicate depth (left % divisor) offset &&
          checkMask predicate depth (left / divisor) (offset + half)

 theorem checkMask_sound {predicate : Nat → Bool} {depth left offset value : Nat}
    (hcheck : checkMask predicate depth left offset = true)
    (hbit : left.testBit value = true) : predicate (offset + value) = true := by
  induction depth generalizing left offset value with
  | zero =>
      have hh : left = 0 ∨ left = 1 ∧ predicate offset = true := by
        simpa only [checkMask, Bool.or_eq_true, Bool.and_eq_true, beq_iff_eq] using hcheck
      rcases hh with hz | ⟨ho, hr⟩
      · simp [hz] at hbit
      · have hv : value = 0 := by simpa [ho, Nat.testBit_one_eq_true_iff_self_eq_zero] using hbit
        simpa [hv] using hr
  | succ depth ih =>
      by_cases hz : left = 0
      · simp [hz] at hbit
      · have hh : checkMask predicate depth (left % 2 ^ (2 ^ depth)) offset = true ∧
            checkMask predicate depth (left / 2 ^ (2 ^ depth)) (offset + 2 ^ depth) = true := by
          simpa only [checkMask, beq_eq_false_iff_ne.mpr hz, Bool.false_eq_true, ↓reduceIte,
            Bool.and_eq_true] using hcheck
        by_cases hv : value < 2 ^ depth
        · have hm : (left % 2 ^ (2 ^ depth)).testBit value = true := by
            simpa [Nat.testBit_mod_two_pow, hv] using hbit
          exact ih hh.1 hm
        · have hd : (left / 2 ^ (2 ^ depth)).testBit (value - 2 ^ depth) = true := by
            rw [← Nat.testBit_add]
            have heq : value - 2 ^ depth + 2 ^ depth = value := by omega
            simpa only [heq] using hbit
          have result := ih hh.2 hd
          have heq : offset + 2 ^ depth + (value - 2 ^ depth) = offset + value := by omega
          simpa only [heq] using result

def scanTree (row : Nat → Nat) (right depth left offset : Nat) : Bool :=
  checkMask (fun index => (row index &&& right) == 0) depth left offset

 theorem scanTree_sound {row : Nat → Nat} {right depth left offset value : Nat}
    (hcheck : scanTree row right depth left offset = true)
    (hbit : left.testBit value = true) : row (offset + value) &&& right = 0 :=
  beq_iff_eq.mp (checkMask_sound hcheck hbit)

/-- Kernel-friendly table oracle, with `2 ^ depth` possible indices. -/
def treeExcludes (table : RelationTable α) (depth : Nat) : Excludes α :=
  fun source target left right => scanTree (table source target) right depth left 0

 theorem treeExcludes_sound {valid : Assignment α → Prop} {table : RelationTable α}
    (hsound : TableSound valid table) (depth : Nat) :
    ExcludesSound valid (treeExcludes table depth) := by
  intro source target left right hcheck assignment hvalid hl hr
  have hzero := scanTree_sound hcheck hl
  have hrow := hsound assignment hvalid source target
  have hbit := congrArg (fun n => n.testBit (assignment target)) hzero
  simp only [Nat.zero_add] at hbit
  simp [hrow, hr] at hbit

/-- Disjointness by binary subdivision, skipping zero blocks on either side. -/
def disjointBits : Nat → Nat → Nat → Bool
  | 0, left, right => left == 0 || right == 0
  | depth + 1, left, right =>
      if left == 0 || right == 0 then true else
        let divisor := 2 ^ (2 ^ depth)
        disjointBits depth (left % divisor) (right % divisor) &&
          disjointBits depth (left / divisor) (right / divisor)

 theorem disjointBits_sound {depth left right value : Nat}
    (hcheck : disjointBits depth left right = true)
    (hl : left.testBit value = true) (hr : right.testBit value = true) : False := by
  induction depth generalizing left right value with
  | zero =>
      have hh : left = 0 ∨ right = 0 := by simpa [disjointBits] using hcheck
      rcases hh with h | h
      · simp [h] at hl
      · simp [h] at hr
  | succ depth ih =>
      by_cases hz : left = 0 ∨ right = 0
      · rcases hz with h | h
        · simp [h] at hl
        · simp [h] at hr
      · have hlz : left ≠ 0 := fun h => hz (Or.inl h)
        have hrz : right ≠ 0 := fun h => hz (Or.inr h)
        have hh : disjointBits depth (left % 2 ^ (2 ^ depth)) (right % 2 ^ (2 ^ depth)) = true ∧
            disjointBits depth (left / 2 ^ (2 ^ depth)) (right / 2 ^ (2 ^ depth)) = true := by
          simpa [disjointBits, hlz, hrz] using hcheck
        by_cases hv : value < 2 ^ depth
        · apply ih (value := value) hh.1
          · simpa [Nat.testBit_mod_two_pow, hv] using hl
          · simpa [Nat.testBit_mod_two_pow, hv] using hr
        · have heq : value - 2 ^ depth + 2 ^ depth = value := by omega
          apply ih (value := value - 2 ^ depth) hh.2
          · rw [← Nat.testBit_add]
            simpa only [heq] using hl
          · rw [← Nat.testBit_add]
            simpa only [heq] using hr

/-- Both source enumeration and pair exclusion use sparse binary subdivision. -/
def sparseExcludes (table : RelationTable α) (depth : Nat) : Excludes α :=
  fun source target left right =>
    checkMask (fun value => disjointBits depth (table source target value) right) depth left 0

 theorem sparseExcludes_sound {valid : Assignment α → Prop} {table : RelationTable α}
    (hsound : TableSound valid table) (depth : Nat) :
    ExcludesSound valid (sparseExcludes table depth) := by
  intro source target left right hcheck assignment hvalid hl hr
  have hd : disjointBits depth (table source target (assignment source)) right = true := by
    simpa only [Nat.zero_add] using checkMask_sound hcheck hl
  exact disjointBits_sound hd (hsound assignment hvalid source target) hr

/-- Sparse block splitting, using ordinary bitwise-and only in small leaves. -/
def disjointBlocks (leafDepth : Nat) : Nat → Nat → Nat → Bool
  | 0, left, right => (left &&& right) == 0
  | depth + 1, left, right =>
      if left == 0 || right == 0 then true else
        let divisor := 2 ^ (2 ^ (depth + leafDepth))
        disjointBlocks leafDepth depth (left % divisor) (right % divisor) &&
          disjointBlocks leafDepth depth (left / divisor) (right / divisor)

 theorem disjointBlocks_sound {leafDepth depth left right value : Nat}
    (hcheck : disjointBlocks leafDepth depth left right = true)
    (hl : left.testBit value = true) (hr : right.testBit value = true) : False := by
  induction depth generalizing left right value with
  | zero =>
      have hz : left &&& right = 0 := by simpa only [disjointBlocks, beq_iff_eq] using hcheck
      have hb := congrArg (fun n => n.testBit value) hz
      simp [hl, hr] at hb
  | succ depth ih =>
      by_cases hz : left = 0 ∨ right = 0
      · rcases hz with h | h
        · simp [h] at hl
        · simp [h] at hr
      · have hlz : left ≠ 0 := fun h => hz (Or.inl h)
        have hrz : right ≠ 0 := fun h => hz (Or.inr h)
        have hh : disjointBlocks leafDepth depth
              (left % 2 ^ (2 ^ (depth + leafDepth))) (right % 2 ^ (2 ^ (depth + leafDepth))) = true ∧
            disjointBlocks leafDepth depth
              (left / 2 ^ (2 ^ (depth + leafDepth))) (right / 2 ^ (2 ^ (depth + leafDepth))) = true := by
          simpa [disjointBlocks, hlz, hrz] using hcheck
        by_cases hv : value < 2 ^ (depth + leafDepth)
        · apply ih (value := value) hh.1
          · simpa [Nat.testBit_mod_two_pow, hv] using hl
          · simpa [Nat.testBit_mod_two_pow, hv] using hr
        · have heq : value - 2 ^ (depth + leafDepth) + 2 ^ (depth + leafDepth) = value := by omega
          apply ih (value := value - 2 ^ (depth + leafDepth)) hh.2
          · rw [← Nat.testBit_add]
            simpa only [heq] using hl
          · rw [← Nat.testBit_add]
            simpa only [heq] using hr

/-- Tune the small block size without changing any semantic hypothesis. -/
def blockExcludes (leafDepth : Nat) (table : RelationTable α) (depth : Nat) : Excludes α :=
  fun source target left right =>
    checkMask (fun value => disjointBlocks leafDepth (depth - leafDepth)
      (table source target value) right) depth left 0

 theorem blockExcludes_sound {valid : Assignment α → Prop} {table : RelationTable α}
    (hsound : TableSound valid table) (leafDepth depth : Nat) :
    ExcludesSound valid (blockExcludes leafDepth table depth) := by
  intro source target left right hcheck assignment hvalid hl hr
  have hd : disjointBlocks leafDepth (depth - leafDepth)
      (table source target (assignment source)) right = true := by
    simpa only [Nat.zero_add] using checkMask_sound hcheck hl
  exact disjointBlocks_sound hd (hsound assignment hvalid source target) hr

/-- A table-based oracle. The fuel is a bound on the number of value indices. -/
def tableExcludes (table : RelationTable α) (fuel : Nat) : Excludes α :=
  fun source target left right => scanRows (table source target) right fuel left 0

 theorem tableExcludes_sound {valid : Assignment α → Prop} {table : RelationTable α}
    (hsound : TableSound valid table) (fuel : Nat) :
    ExcludesSound valid (tableExcludes table fuel) := by
  intro source target left right hcheck assignment hvalid hl hr
  have hzero := scanRows_sound hcheck hl
  have hrow := hsound assignment hvalid source target
  have hbit := congrArg (fun n => n.testBit (assignment target)) hzero
  simp only [Nat.zero_add] at hbit
  simp [hrow, hr] at hbit

/-- Either orientation can be used, with a supplied, entirely untrusted hint. -/
def tableExcludesHinted (table : RelationTable α) (fuel : Nat)
    (reverseHint : α → α → Nat → Nat → Bool) : Excludes α :=
  fun source target left right =>
    if reverseHint source target left right then
      tableExcludes table fuel target source right left
    else tableExcludes table fuel source target left right

 theorem tableExcludesHinted_sound {valid : Assignment α → Prop} {table : RelationTable α}
    (hsound : TableSound valid table) (fuel : Nat)
    (reverseHint : α → α → Nat → Nat → Bool) :
    ExcludesSound valid (tableExcludesHinted table fuel reverseHint) := by
  intro source target left right hcheck assignment hvalid hl hr
  simp only [tableExcludesHinted] at hcheck
  split at hcheck
  · exact tableExcludes_sound hsound fuel target source right left hcheck assignment hvalid hr hl
  · exact tableExcludes_sound hsound fuel source target left right hcheck assignment hvalid hl hr

end LockedHeptomino.CSP

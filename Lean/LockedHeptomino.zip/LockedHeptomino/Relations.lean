import LockedHeptomino.Isometry
import LockedHeptomino.CSPTable
import LockedHeptomino.Enumeration

namespace LockedHeptomino

set_option maxRecDepth 4096

def direction (d : Nat) : Cell :=
  match d with
  | 0 => (0, 1)
  | 1 => (1, 0)
  | 2 => (0, -1)
  | _ => (-1, 0)

/-- Inverted cell incidence is much smaller than the pair relation table:
there are only seven occupied incidences for each rooted type. -/
def IncidenceSound (types : Nat → Finset Cell) (incidence : Cell → Nat) : Prop :=
  ∀ p value, (incidence p).testBit value = true → p ∈ types value

structure IncidenceEntry where
  cell : Cell
  mask : Nat

def IncidenceEntry.check (types : Nat → Finset Cell) (entry : IncidenceEntry) : Bool :=
  CSP.checkMask (fun value => decide (entry.cell ∈ types value)) 13 entry.mask 0

def incidenceKey (p : Cell) : Nat := (p.1 + 6).toNat * 13 + (p.2 + 6).toNat

/-- The equality guard makes the address arithmetic untrusted: an incorrect
address can only remove overlap exclusions, never introduce false ones. -/
def incidenceFrom (catalog : LookupTree IncidenceEntry) (p : Cell) : Nat :=
  let entry := catalog.lookup (incidenceKey p)
  if entry.cell = p then entry.mask else 0

theorem incidenceFrom_sound {types : Nat → Finset Cell} {catalog : LookupTree IncidenceEntry}
    (hcheck : catalog.all (IncidenceEntry.check types) = true) :
    IncidenceSound types (incidenceFrom catalog) := by
  intro p value hbit
  unfold incidenceFrom at hbit
  dsimp only at hbit
  split at hbit
  · rename_i hcell
    have he := LookupTree.all_lookup hcheck (incidenceKey p)
    have hm := CSP.checkMask_sound he hbit
    have hp : (catalog.lookup (incidenceKey p)).cell ∈ types value := by
      simpa only [Nat.zero_add, decide_eq_true_eq] using hm
    simpa only [hcell] using hp
  · simp at hbit

def overlapMask (incidence : Cell → Nat) (delta : Cell) : List Cell → Nat
  | [] => 0
  | p :: cells => incidence (shiftCell (negCell delta) p) ||| overlapMask incidence delta cells

theorem overlapMask_sound {types : Nat → Finset Cell} {incidence : Cell → Nat}
    (hincidence : IncidenceSound types incidence) (delta : Cell) (cells : List Cell)
    {value : Nat} (hbit : (overlapMask incidence delta cells).testBit value = true) :
    ¬ Disjoint cells.toFinset (translate delta (types value)) := by
  induction cells with
  | nil => simp [overlapMask] at hbit
  | cons p cells ih =>
      have hh : (incidence (shiftCell (negCell delta) p)).testBit value = true ∨
          (overlapMask incidence delta cells).testBit value = true := by
        simpa only [overlapMask, Nat.testBit_or, Bool.or_eq_true] using hbit
      intro hd
      rw [Finset.disjoint_left] at hd
      rcases hh with hp | htail
      · exact hd (by simp) (mem_translate_iff.mpr (hincidence _ _ hp))
      · apply ih htail
        rw [Finset.disjoint_left]
        intro q hq hqt
        exact hd (by simp [hq]) hqt

/-- An index for the unique target type describing the same placed tile.
The distinguished value may be out of range when no such target exists. -/
def EqualIndexSound (types : Nat → Finset Cell) (same : Nat → Nat → Nat) : Prop :=
  ∀ d, d < 4 → ∀ a b, a < 5320 → b < 5320 →
    types a = translate (direction d) (types b) → b = same d a

def sameIndexCheck (types : Nat → Finset Cell) (d a same : Nat) : Bool :=
  if direction d ∈ types a then
    decide (same < 5320) && decide (types a = translate (direction d) (types same))
  else true

def sameDirectionCheck (types : Nat → Finset Cell) (same : Nat → Nat → Nat)
    (d : Nat) : Bool :=
  (List.range 5320).all fun a => sameIndexCheck types d a (same d a)

theorem sameDirectionCheck_sound {types : Nat → Finset Cell} {same : Nat → Nat → Nat}
    {d : Nat} (h : sameDirectionCheck types same d = true) {a : Nat} (ha : a < 5320) :
    sameIndexCheck types d a (same d a) = true :=
  List.all_eq_true.mp h a (List.mem_range.mpr ha)

theorem sameIndexCheck_sound {types : Nat → Finset Cell} {same : Nat → Nat → Nat}
    (hroot : ∀ i < 5320, origin ∈ types i)
    (hinj : ∀ i < 5320, ∀ j < 5320, types i = types j → i = j)
    (hcheck : ∀ d < 4, ∀ a < 5320, sameIndexCheck types d a (same d a) = true) :
    EqualIndexSound types same := by
  intro d hd a b ha hb heq
  have hdelta : direction d ∈ types a := by
    rw [heq]
    apply Finset.mem_image.mpr
    exact ⟨origin, hroot b hb, by ext <;> simp [origin, shiftCell]⟩
  have hc : same d a < 5320 ∧ types a = translate (direction d) (types (same d a)) := by
    simpa only [sameIndexCheck, if_pos hdelta, Bool.and_eq_true, decide_eq_true_eq]
      using hcheck d hd a ha
  apply hinj b hb (same d a) hc.1
  have ht := congrArg (translate (negCell (direction d))) (heq.symm.trans hc.2)
  simpa using ht

def overlapForbidden (incidence : Cell → Nat) (same : Nat → Nat → Nat)
    (d a : Nat) (cells : List Cell) : Nat :=
  overlapMask incidence (direction d) cells &&& ((2 ^ 5320 - 1) ^^^ 2 ^ same d a)

theorem overlapForbidden_sound {types : Nat → Finset Cell} {incidence : Cell → Nat}
    {same : Nat → Nat → Nat} (hi : IncidenceSound types incidence)
    (he : EqualIndexSound types same) {d a b : Nat} (hd : d < 4)
    (ha : a < 5320) (hb : b < 5320)
    {cells : List Cell} (hcells : cells.toFinset = types a)
    (hbit : (overlapForbidden incidence same d a cells).testBit b = true) :
    ¬ Compatible (types a) (translate (direction d) (types b)) := by
  have hh : (overlapMask incidence (direction d) cells).testBit b = true ∧
      same d a ≠ b := by
    simpa [overlapForbidden, Nat.testBit_two_pow_sub_one, Nat.testBit_two_pow, hb] using hbit
  intro hcompat
  rcases hcompat with heq | ⟨hdisj, _⟩
  · exact hh.2 (he d hd a b ha hb heq).symm
  · exact overlapMask_sound hi _ cells hh.1 (hcells.symm ▸ hdisj)

/-- A list of individually certified flexible pairs supplies another mask. -/
def targetsMask {α : Type} (target : α → Nat) : List α → Nat
  | [] => 0
  | entry :: rest => 2 ^ target entry ||| targetsMask target rest

theorem targetsMask_mem {α : Type} {target : α → Nat} {entries : List α} {b : Nat}
    (hbit : (targetsMask target entries).testBit b = true) :
    ∃ entry ∈ entries, target entry = b := by
  induction entries with
  | nil => simp [targetsMask] at hbit
  | cons entry rest ih =>
      have hh : target entry = b ∨ (targetsMask target rest).testBit b = true := by
        simpa [targetsMask, Nat.testBit_two_pow] using hbit
      rcases hh with hhead | htail
      · exact ⟨entry, by simp, hhead⟩
      · obtain ⟨other, hother, heq⟩ := ih htail
        exact ⟨other, List.mem_cons_of_mem _ hother, heq⟩

/-- The original forbidden mask must be covered by sound exclusions.  This
single large-integer check replaces tens of millions of per-pair overlap tests. -/
def coverageCheck (forbidden overlap flexible : Nat) : Bool :=
  (forbidden &&& ((2 ^ 5320 - 1) ^^^ (overlap ||| flexible))) == 0

theorem coverageCheck_sound {forbidden overlap flexible b : Nat} (hb : b < 5320)
    (hcheck : coverageCheck forbidden overlap flexible = true)
    (hforbidden : forbidden.testBit b = true) :
    overlap.testBit b = true ∨ flexible.testBit b = true := by
  have hz : forbidden &&& ((2 ^ 5320 - 1) ^^^ (overlap ||| flexible)) = 0 :=
    beq_iff_eq.mp hcheck
  have h := congrArg (fun x => x.testBit b) hz
  simp only [Nat.testBit_and, Nat.testBit_xor, Nat.testBit_two_pow_sub_one,
    decide_eq_true hb, Nat.testBit_or, hforbidden, Bool.true_and, Nat.zero_testBit] at h
  cases ho : overlap.testBit b <;> cases hf : flexible.testBit b <;> simp_all

theorem forbiddenRow_sound {types : Nat → Finset Cell} {incidence : Cell → Nat}
    {same : Nat → Nat → Nat} {α : Type} {target : α → Nat} {pairCheck : α → Bool}
    (hi : IncidenceSound types incidence) (he : EqualIndexSound types same)
    {d a b : Nat} (hd : d < 4) (ha : a < 5320) (hb : b < 5320)
    {cells : List Cell} (hcells : cells.toFinset = types a)
    {entries : List α} (hpairs : entries.all pairCheck = true)
    (hpairSound : ∀ entry ∈ entries, pairCheck entry = true →
      ¬ Compatible (types a) (translate (direction d) (types (target entry))))
    {forbidden : Nat}
    (hcover : coverageCheck forbidden (overlapForbidden incidence same d a cells)
      (targetsMask target entries) = true)
    (hbit : forbidden.testBit b = true) :
    ¬ Compatible (types a) (translate (direction d) (types b)) := by
  rcases coverageCheck_sound hb hcover hbit with ho | hf
  · exact overlapForbidden_sound hi he hd ha hb hcells ho
  · obtain ⟨entry, hentry, heq⟩ := targetsMask_mem hf
    have hc : pairCheck entry = true := (List.all_eq_true.mp hpairs) _ hentry
    simpa only [heq] using hpairSound entry hentry hc

end LockedHeptomino

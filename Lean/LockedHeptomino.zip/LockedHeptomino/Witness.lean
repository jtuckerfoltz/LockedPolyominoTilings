import LockedHeptomino.Tiling

namespace LockedHeptomino

def adjacentCheck (p q : Cell) : Bool :=
  ((q.1 == p.1 + 1 || q.1 == p.1 - 1) && q.2 == p.2) ||
  ((q.2 == p.2 + 1 || q.2 == p.2 - 1) && q.1 == p.1)

theorem adjacentCheck_iff (p q : Cell) : adjacentCheck p q = true ↔ Adjacent p q := by
  simp only [adjacentCheck, Bool.or_eq_true, Bool.and_eq_true, beq_iff_eq,
    adjacent_iff, Prod.mk.injEq]
  aesop

/-- A connectivity certificate: every cell attaches to a later cell. -/
def connectedOrder : List Cell → Bool
  | [] => false
  | [_] => true
  | p :: q :: rest =>
      ((q :: rest).any fun r => adjacentCheck r p) && connectedOrder (q :: rest)

theorem connectedOrder_sound (cells : List Cell) (h : connectedOrder cells = true) :
    Connected cells.toFinset := by
  induction cells with
  | nil => simp [connectedOrder] at h
  | cons p tail ih =>
    cases tail with
    | nil => simpa using connected_singleton p
    | cons q rest =>
      have hh : (∃ r ∈ q :: rest, Adjacent r p) ∧ connectedOrder (q :: rest) = true := by
        simpa only [connectedOrder, Bool.and_eq_true, List.any_eq_true, adjacentCheck_iff] using h
      obtain ⟨r,hr,hrp⟩ := hh.1
      simpa using connected_insert (ih hh.2) (List.mem_toFinset.mpr hr) hrp

/-- Two distinct unordered partitions of the same union, with growth orders. -/
structure SplitWitness where
  firstLeft : List Cell
  firstRight : List Cell
  secondLeft : List Cell
  secondRight : List Cell
  deriving Repr

def SplitWitness.union (w : SplitWitness) : Finset Cell :=
  w.firstLeft.toFinset ∪ w.firstRight.toFinset

def listSubsetCheck (a b : List Cell) : Bool := a.all fun p => b.contains p

theorem listSubsetCheck_iff (a b : List Cell) :
    listSubsetCheck a b = true ↔ a.toFinset ⊆ b.toFinset := by
  simp [listSubsetCheck, List.all_eq_true, Finset.subset_iff]

def listDisjointCheck (a b : List Cell) : Bool := a.all fun p => !(b.contains p)

theorem listDisjointCheck_iff (a b : List Cell) :
    listDisjointCheck a b = true ↔ Disjoint a.toFinset b.toFinset := by
  simp [listDisjointCheck, List.all_eq_true, Finset.disjoint_left]

def tileOrderCheck (a : List Cell) : Bool :=
  connectedOrder a && (a.length == 7) && decide a.Nodup

theorem tileOrderCheck_sound (a : List Cell) (h : tileOrderCheck a = true) :
    Connected a.toFinset ∧ a.toFinset.card = 7 := by
  simp only [tileOrderCheck, Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq] at h
  exact ⟨connectedOrder_sound _ h.1.1, by simpa [List.toFinset_card_of_nodup h.2] using h.1.2⟩

def SplitWitness.check (w : SplitWitness) : Bool :=
  tileOrderCheck w.firstLeft && tileOrderCheck w.firstRight &&
  tileOrderCheck w.secondLeft && tileOrderCheck w.secondRight &&
  listDisjointCheck w.firstLeft w.firstRight &&
  listDisjointCheck w.secondLeft w.secondRight &&
  listSubsetCheck (w.firstLeft ++ w.firstRight) (w.secondLeft ++ w.secondRight) &&
  listSubsetCheck (w.secondLeft ++ w.secondRight) (w.firstLeft ++ w.firstRight) &&
  !(listSubsetCheck w.firstLeft w.secondLeft) &&
  !(listSubsetCheck w.firstLeft w.secondRight)

/-- Accepted data rule out rigidity for every original partition of this union. -/
theorem SplitWitness.not_rigid (w : SplitWitness) (hw : w.check = true)
    (a b : Finset Cell) (hu : a ∪ b = w.union) : ¬ RigidPair a b := by
  simp only [SplitWitness.check, Bool.and_eq_true] at hw
  rcases hw with ⟨⟨⟨⟨⟨⟨⟨⟨⟨hc,hd⟩,he⟩,hf⟩,hcd⟩,hef⟩,hu1⟩,hu2⟩,hne1⟩,hne2⟩
  obtain ⟨hc,hc7⟩ := tileOrderCheck_sound _ hc
  obtain ⟨hd,hd7⟩ := tileOrderCheck_sound _ hd
  obtain ⟨he,he7⟩ := tileOrderCheck_sound _ he
  obtain ⟨hf,hf7⟩ := tileOrderCheck_sound _ hf
  have hcd := (listDisjointCheck_iff _ _).mp hcd
  have hef := (listDisjointCheck_iff _ _).mp hef
  have hunion : w.firstLeft.toFinset ∪ w.firstRight.toFinset =
      w.secondLeft.toFinset ∪ w.secondRight.toFinset := by
    apply Finset.Subset.antisymm
    · simpa using (listSubsetCheck_iff _ _).mp hu1
    · simpa using (listSubsetCheck_iff _ _).mp hu2
  have hce : w.firstLeft.toFinset ≠ w.secondLeft.toFinset := by
    intro hh
    have ht : listSubsetCheck w.firstLeft w.secondLeft = true :=
      (listSubsetCheck_iff _ _).mpr (hh ▸ Finset.Subset.refl _)
    simp [ht] at hne1
  have hcf : w.firstLeft.toFinset ≠ w.secondRight.toFinset := by
    intro hh
    have ht : listSubsetCheck w.firstLeft w.secondRight = true :=
      (listSubsetCheck_iff _ _).mpr (hh ▸ Finset.Subset.refl _)
    simp [ht] at hne2
  intro hr
  have hfirst := hr _ _ hc hd
    hc7 hd7 hcd hu.symm
  have hsecond := hr _ _ he hf
    he7 hf7 hef (hunion.symm.trans hu.symm)
  rcases hfirst with ⟨ha,hb⟩ | ⟨ha,hb⟩ <;>
    rcases hsecond with ⟨he,hf⟩ | ⟨he,hf⟩
  · exact hce (ha.trans he.symm)
  · exact hcf (ha.trans hf.symm)
  · exact hcf (ha.trans hf.symm)
  · exact hce (ha.trans he.symm)

end LockedHeptomino

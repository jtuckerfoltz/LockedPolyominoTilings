import LockedHeptomino.IndexedModel

namespace LockedHeptomino

/-- Arithmetic bit lookup, reduced using the kernel's integer arithmetic. -/
def bitCheck (mask index : Nat) : Bool := mask / 2 ^ index % 2 == 1

theorem bitCheck_eq (mask index : Nat) : bitCheck mask index = mask.testBit index := by
  apply Bool.eq_iff_iff.mpr
  simp [bitCheck, Nat.testBit_to_div_mod]

def wallsCheck (width : Nat) (strip : Bool) (position : Cell) (shape : List Cell) : Bool :=
  shape.all fun q =>
    decide (0 ≤ q.1 + position.1) && decide (0 ≤ q.2 + position.2) &&
      (!strip || decide (q.2 + position.2 < width))

theorem wallsCheck_iff (width : Nat) (strip : Bool) (position : Cell) (shape : List Cell) :
    wallsCheck width strip position shape = true ↔ Walls width strip (translate position shape.toFinset) := by
  simp only [wallsCheck, List.all_eq_true, Bool.and_eq_true, Bool.or_eq_true,
    Bool.not_eq_true', decide_eq_true_eq, Walls, translate, Finset.mem_image]
  constructor
  · intro h q hq
    obtain ⟨a,ha,rfl⟩ := hq
    obtain ⟨⟨hr,hc⟩,hs⟩ := h a (List.mem_toFinset.mp ha)
    refine ⟨hr,hc,?_⟩
    intro hstrip
    rcases hs with hs | hs
    · simp [hstrip] at hs
    · exact hs
  · intro h a ha
    have ht := h (shiftCell position a)
      ⟨a,List.mem_toFinset.mpr ha,rfl⟩
    refine ⟨⟨ht.1,ht.2.1⟩,?_⟩
    cases strip with
    | false => exact Or.inl rfl
    | true => exact Or.inr (ht.2.2 rfl)

/-- This checks an overapproximation: any type omitted by the initial domain
must fail an actual wall constraint. It does not assume the domain generator. -/
def initialCellCheck (types : Nat → List Cell) (width : Nat) (strip : Bool)
    (cell domain : Nat) : Bool :=
  (List.range 5320).all fun value =>
    bitCheck domain value || !(wallsCheck width strip (cellPosition width cell) (types value))

theorem initialCellCheck_sound (types : Nat → List Cell) (width : Nat) (strip : Bool)
    (cell domain : Nat) (hcheck : initialCellCheck types width strip cell domain = true)
    (value : Nat) (hvalue : value < 5320)
    (hwalls : Walls width strip (translate (cellPosition width cell) (types value).toFinset)) :
    domain.testBit value = true := by
  have hall := List.all_eq_true.mp hcheck value (List.mem_range.mpr hvalue)
  have hw := (wallsCheck_iff _ _ _ _).mpr hwalls
  simpa only [hw, Bool.not_true, Bool.or_false, bitCheck_eq] using hall

end LockedHeptomino

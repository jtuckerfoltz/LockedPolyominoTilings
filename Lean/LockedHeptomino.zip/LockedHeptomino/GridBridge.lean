import LockedHeptomino.IndexedModel
import LockedHeptomino.Relations

namespace LockedHeptomino

theorem translate_comp (v w : Cell) (s : Finset Cell) :
    translate v (translate w s) = translate (shiftCell v w) s := by
  simp only [translate, Finset.image_image]
  congr 1
  funext p
  ext <;> simp [shiftCell, Function.comp_def, add_assoc]

theorem compatible_at_origin {types : Nat → Finset Cell} {p q delta : Cell} {a b : Nat}
    (hpq : q = shiftCell p delta)
    (hc : Compatible (translate p (types a)) (translate q (types b))) :
    Compatible (types a) (translate delta (types b)) := by
  have hc' := (translateIso (negCell p)).compatible_map hc
  change Compatible (translate (negCell p) (translate p (types a)))
    (translate (negCell p) (translate q (types b))) at hc'
  rw [translate_neg_cancel, translate_comp] at hc'
  have hd : shiftCell (negCell p) q = delta := by
    rw [hpq]
    ext <;> simp [shiftCell, negCell]
  simpa only [hd] using hc'

def DirectionalSound (types : Nat → Finset Cell) (rows : Nat → Nat → Nat) : Prop :=
  ∀ d a b, d < 4 → a < 5320 → b < 5320 →
    Compatible (types a) (translate (direction d) (types b)) →
    (rows d a).testBit b = true

theorem indexed_gridTable_sound {types : Nat → Finset Cell} {rows : Nat → Nat → Nat}
    (hr : DirectionalSound types rows) (h w : Nat) (strip : Bool) :
    CSP.TableSound (IndexedValid types h w strip)
      (CSP.gridTable w (2^5320-1) rows) := by
  intro assignment hv source target
  have step (d : Nat) (hd : d < 4)
      (hpq : cellPosition w target.val = shiftCell (cellPosition w source.val) (direction d)) :
      (rows d (assignment source)).testBit (assignment target) = true := by
    have hadj : Adjacent (cellPosition w source.val) (cellPosition w target.val) := by
      rw [hpq]
      interval_cases d <;> simp [direction, adjacent_iff, shiftCell, add_comm, sub_eq_add_neg]
    exact hr d _ _ hd (hv.bounded source) (hv.bounded target)
      (compatible_at_origin hpq (hv.compatible source target hadj))
  unfold CSP.gridTable
  split
  · rename_i he
    apply step 0 (by decide)
    apply Prod.ext <;> simp only [cellPosition,shiftCell,direction,zero_add]
    · exact_mod_cast he.1.symm
    · exact_mod_cast (show target.val % w = 1 + source.val % w by omega)
  · split
    · rename_i he
      apply step 1 (by decide)
      apply Prod.ext <;> simp only [cellPosition,shiftCell,direction,zero_add]
      · exact_mod_cast (show target.val / w = 1 + source.val / w by omega)
      · exact_mod_cast he.1.symm
    · split
      · rename_i he
        apply step 2 (by decide)
        apply Prod.ext <;> simp only [cellPosition,shiftCell,direction,zero_add]
        · exact_mod_cast he.1.symm
        · have hc : (target.val % w : Int) + 1 = (source.val % w : Int) := by exact_mod_cast he.2
          omega
      · split
        · rename_i he
          apply step 3 (by decide)
          apply Prod.ext <;> simp only [cellPosition,shiftCell,direction,zero_add]
          · have hr : (target.val / w : Int) + 1 = (source.val / w : Int) := by exact_mod_cast he.2
            omega
          · exact_mod_cast he.1.symm
        · simpa only [Nat.testBit_two_pow_sub_one, decide_eq_true_eq] using hv.bounded target

end LockedHeptomino

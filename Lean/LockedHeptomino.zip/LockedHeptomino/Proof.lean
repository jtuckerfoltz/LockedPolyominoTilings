import LockedHeptomino.OneDimension
import LockedHeptomino.GridBridge
import LockedHeptomino.Generated.InitialComplete
import LockedHeptomino.Generated.RelationsComplete
import LockedHeptomino.Generated.CheckedQuadrant7x7
import LockedHeptomino.Generated.CheckedStrip7x2
import LockedHeptomino.Generated.CheckedStrip7x3
import LockedHeptomino.Generated.CheckedStrip7x4
import LockedHeptomino.Generated.CheckedStrip7x5
import LockedHeptomino.Generated.CheckedStrip7x6

namespace LockedHeptomino

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option exponentiation.threshold 16384

private theorem complete_types : RootedComplete Generated.typeShape := by
  intro s hs hr hc
  exact Generated.rooted_type_exists hs hr hc

private theorem obstruction_from_checked_assignment {h w : Nat} (hw : 0 < w)
    (strip : Bool) (initial : CSP.Domains (Fin (h*w)))
    (hi : InitialSound Generated.typeShape h w strip initial)
    (unsat : ∀ assignment, IndexedValid Generated.typeShape h w strip assignment →
      CSP.Fits initial assignment → False) : ∀ tile, ¬ PatchValid h w strip tile := by
  intro tile hv
  obtain ⟨assignment,ha⟩ := indexed_of_patch complete_types hw hv
  exact unsat assignment ha (initial_fits hi ha)

/-- All six geometric obstructions, with every computational premise discharged. -/
theorem checked_local_obstructions : LocalObstructions := by
  have tables := indexed_gridTable_sound Generated.permittedRows_sound
  constructor
  · exact obstruction_from_checked_assignment (by decide) false
      Generated.InitialDomains.quadrant7x7 Generated.quadrant7x7_initial_sound
      (Generated.CheckedQuadrant7x7.no_assignment (tables 7 7 false))
  · intro width hlo hhi
    interval_cases width
    · exact obstruction_from_checked_assignment (by decide) true
        Generated.InitialDomains.strip7x2 Generated.strip7x2_initial_sound
        (Generated.CheckedStrip7x2.no_assignment (tables 7 2 true))
    · exact obstruction_from_checked_assignment (by decide) true
        Generated.InitialDomains.strip7x3 Generated.strip7x3_initial_sound
        (Generated.CheckedStrip7x3.no_assignment (tables 7 3 true))
    · exact obstruction_from_checked_assignment (by decide) true
        Generated.InitialDomains.strip7x4 Generated.strip7x4_initial_sound
        (Generated.CheckedStrip7x4.no_assignment (tables 7 4 true))
    · exact obstruction_from_checked_assignment (by decide) true
        Generated.InitialDomains.strip7x5 Generated.strip7x5_initial_sound
        (Generated.CheckedStrip7x5.no_assignment (tables 7 5 true))
    · exact obstruction_from_checked_assignment (by decide) true
        Generated.InitialDomains.strip7x6 Generated.strip7x6_initial_sound
        (Generated.CheckedStrip7x6.no_assignment (tables 7 6 true))

/-- Every tiling of a rectangle with both sides at least two can be recombined. -/
theorem no_locked_heptomino_rectangle {height width : Nat}
    (hh : 2 ≤ height) (hw : 2 ≤ width) (tiling : HeptominoTiling height width) :
    ¬ tiling.Locked :=
  no_locked_rectangle_of_obstructions checked_local_obstructions hh hw tiling

/-- No nondegenerate finite rectangular grid has a locked heptomino tiling.
Nondegenerate means another unlabelled tiling of the same board exists. -/
theorem no_locked_nondegenerate_heptomino_rectangle {height width : Nat}
    (tiling : HeptominoTiling height width) (hn : tiling.Nondegenerate) :
    ¬ tiling.Locked :=
  no_locked_nondegenerate_rectangle_of_obstructions checked_local_obstructions tiling hn

end LockedHeptomino

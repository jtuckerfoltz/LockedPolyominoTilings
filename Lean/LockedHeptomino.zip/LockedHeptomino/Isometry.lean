import LockedHeptomino.Witness

namespace LockedHeptomino

/-- A bijection of grid cells preserving and reflecting edge adjacency. -/
structure GridIso where
  equiv : Cell ≃ Cell
  adjacent_iff : ∀ p q, Adjacent (equiv p) (equiv q) ↔ Adjacent p q

def GridIso.map (e : GridIso) (s : Finset Cell) : Finset Cell := s.image e.equiv

def GridIso.symm (e : GridIso) : GridIso where
  equiv := e.equiv.symm
  adjacent_iff := by
    intro p q
    have h := e.adjacent_iff (e.equiv.symm p) (e.equiv.symm q)
    simpa using h.symm

def GridIso.trans (e f : GridIso) : GridIso where
  equiv := e.equiv.trans f.equiv
  adjacent_iff := fun p q => (f.adjacent_iff _ _).trans (e.adjacent_iff p q)

@[simp] theorem GridIso.map_card (e : GridIso) (s : Finset Cell) :
    (e.map s).card = s.card := Finset.card_image_of_injective _ e.equiv.injective

@[simp] theorem GridIso.map_union (e : GridIso) (s t : Finset Cell) :
    e.map (s ∪ t) = e.map s ∪ e.map t := Finset.image_union _ _

@[simp] theorem GridIso.map_symm_map (e : GridIso) (s : Finset Cell) :
    e.symm.map (e.map s) = s := by
  simp [GridIso.map, GridIso.symm, Finset.image_image, Function.comp_def]

@[simp] theorem GridIso.map_map_symm (e : GridIso) (s : Finset Cell) :
    e.map (e.symm.map s) = s := by
  simp [GridIso.map, GridIso.symm, Finset.image_image, Function.comp_def]

theorem GridIso.connected_map (e : GridIso) {s : Finset Cell} (hs : Connected s) :
    Connected (e.map s) := by
  constructor
  · obtain ⟨p,hp⟩ := hs.1
    exact ⟨e.equiv p, Finset.mem_image_of_mem _ hp⟩
  · intro a ha b hb
    obtain ⟨a',ha',rfl⟩ := Finset.mem_image.mp ha
    obtain ⟨b',hb',rfl⟩ := Finset.mem_image.mp hb
    have path := hs.2 a' ha' b' hb'
    clear ha hb ha' hb'
    induction path with
    | refl => exact Relation.ReflTransGen.refl
    | tail _ hstep ih =>
      exact ih.tail ⟨Finset.mem_image_of_mem _ hstep.1,
        Finset.mem_image_of_mem _ hstep.2.1, (e.adjacent_iff _ _).mpr hstep.2.2⟩

theorem GridIso.disjoint_map (e : GridIso) {s t : Finset Cell} (h : Disjoint s t) :
    Disjoint (e.map s) (e.map t) := by
  rw [Finset.disjoint_left] at h ⊢
  intro p hp hq
  obtain ⟨a,ha,he⟩ := Finset.mem_image.mp hp
  obtain ⟨b,hb,hf⟩ := Finset.mem_image.mp hq
  have hab := e.equiv.injective (he.trans hf.symm)
  exact h ha (hab ▸ hb)

theorem GridIso.rigid_map (e : GridIso) {a b : Finset Cell} (h : RigidPair a b) :
    RigidPair (e.map a) (e.map b) := by
  intro c d hc hd hc7 hd7 hcd hu
  have hc' := e.symm.connected_map hc
  have hd' := e.symm.connected_map hd
  have hu' : e.symm.map c ∪ e.symm.map d = a ∪ b := by
    have := congrArg e.symm.map hu
    simpa using this
  have hr := h _ _ hc' hd' (by simpa using hc7) (by simpa using hd7)
    (e.symm.disjoint_map hcd) hu'
  rcases hr with ⟨ha,hb⟩ | ⟨ha,hb⟩
  · exact Or.inl ⟨by simpa using congrArg e.map ha, by simpa using congrArg e.map hb⟩
  · exact Or.inr ⟨by simpa using congrArg e.map ha, by simpa using congrArg e.map hb⟩

theorem GridIso.compatible_map (e : GridIso) {a b : Finset Cell} (h : Compatible a b) :
    Compatible (e.map a) (e.map b) := by
  rcases h with h | ⟨hd,hr⟩
  · exact Or.inl (congrArg e.map h)
  · exact Or.inr ⟨e.disjoint_map hd, e.rigid_map hr⟩

def translateIso (v : Cell) : GridIso where
  equiv :=
    { toFun := shiftCell v, invFun := shiftCell (negCell v)
      left_inv := by intro p; ext <;> simp [shiftCell, negCell]
      right_inv := by intro p; ext <;> simp [shiftCell, negCell] }
  adjacent_iff := by
    intro p q
    constructor
    · intro h
      have h' := adjacent_shift h (negCell v)
      simpa [shiftCell, negCell] using h'
    · intro h; exact adjacent_shift h v

def transposeIso : GridIso where
  equiv :=
    { toFun := transposeCell
      invFun := transposeCell
      left_inv := transposeCell_transposeCell
      right_inv := transposeCell_transposeCell }
  adjacent_iff := by
    intro p q
    constructor
    · intro h; simpa using adjacent_transpose h
    · exact adjacent_transpose

def reflectRowCell (p : Cell) : Cell := (-p.1, p.2)

@[simp] theorem reflectRow_twice (p : Cell) : reflectRowCell (reflectRowCell p) = p := by
  ext <;> simp [reflectRowCell]

theorem adjacent_reflectRow {p q : Cell} (h : Adjacent p q) :
    Adjacent (reflectRowCell p) (reflectRowCell q) := by
  rcases p with ⟨px,py⟩
  rcases q with ⟨qx,qy⟩
  simp only [adjacent_iff, reflectRowCell, Prod.mk.injEq] at h ⊢
  omega

def reflectRowIso : GridIso where
  equiv :=
    { toFun := reflectRowCell
      invFun := reflectRowCell
      left_inv := reflectRow_twice
      right_inv := reflectRow_twice }
  adjacent_iff := by
    intro p q
    constructor
    · intro h; simpa using adjacent_reflectRow h
    · exact adjacent_reflectRow

def identityIso : GridIso where
  equiv := Equiv.refl Cell
  adjacent_iff := fun _ _ => Iff.rfl

def reflectColIso : GridIso := transposeIso.trans (reflectRowIso.trans transposeIso)

/-- Indices agree with the untrusted generator's eight signed coordinate maps. -/
def dihedralIso (index : Nat) : GridIso :=
  match index with
  | 0 => identityIso
  | 1 => reflectColIso
  | 2 => reflectRowIso
  | 3 => reflectRowIso.trans reflectColIso
  | 4 => transposeIso
  | 5 => transposeIso.trans reflectColIso
  | 6 => transposeIso.trans reflectRowIso
  | _ => transposeIso.trans (reflectRowIso.trans reflectColIso)

theorem dihedral_shift (index : Nat) (v p : Cell) :
    (dihedralIso index).equiv (shiftCell v p) =
      shiftCell ((dihedralIso index).equiv v) ((dihedralIso index).equiv p) := by
  unfold dihedralIso
  split <;> ext <;>
    simp [GridIso.trans, identityIso, transposeIso, reflectRowIso, reflectColIso,
      shiftCell, transposeCell, reflectRowCell, add_comm]

theorem SplitWitness.not_rigid_of_isometry (w : SplitWitness) (hw : w.check = true)
    (e : GridIso) (a b : Finset Cell) (hu : e.map (a ∪ b) = w.union) : ¬ RigidPair a b := by
  intro h
  exact w.not_rigid hw (e.map a) (e.map b) (by simpa using hu) (e.rigid_map h)

end LockedHeptomino

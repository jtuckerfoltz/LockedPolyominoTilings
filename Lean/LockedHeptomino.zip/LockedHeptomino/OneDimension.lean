import LockedHeptomino.Generated.EnumerationComplete
import LockedHeptomino.IndexedModel

namespace LockedHeptomino

def verticalSeven (base : Int) : Finset Cell :=
  ((List.range 7).map fun (k : Nat) => (base + (k : Int), (0 : Int))).toFinset

@[simp] theorem mem_verticalSeven (base : Int) (p : Cell) :
    p ∈ verticalSeven base ↔ p.2 = 0 ∧ base ≤ p.1 ∧ p.1 < base + 7 := by
  simp only [verticalSeven, List.mem_toFinset, List.mem_map]
  constructor
  · rintro ⟨k,hk,rfl⟩
    have hk' := List.mem_range.mp hk
    have hk0 : (0 : Int) ≤ (k : Int) := Int.natCast_nonneg k
    exact ⟨rfl, by omega, by omega⟩
  · rintro ⟨hp,hlo,hhi⟩
    exact ⟨(p.1-base).toNat,List.mem_range.mpr (by omega),by apply Prod.ext <;> simp <;> omega⟩

def verticalListCheck (cells : List Cell) : Bool :=
  !(cells.all fun p => p.2 == 0) ||
    let line := (List.range 7).map fun (k : Nat) => (cells.head!.1 + (k : Int), (0 : Int))
    listSubsetCheck cells line && listSubsetCheck line cells

theorem verticalListCheck_sound (cells : List Cell) (hc : verticalListCheck cells = true)
    (hcol : ∀ p ∈ cells.toFinset, p.2 = 0) :
    ∃ base, cells.toFinset = verticalSeven base := by
  have ha : (cells.all fun p => p.2 == 0) = true := by
    simp only [List.all_eq_true, beq_iff_eq]
    intro p hp
    exact hcol p (List.mem_toFinset.mpr hp)
  simp only [verticalListCheck, ha, Bool.not_true, Bool.false_or, Bool.and_eq_true,
    listSubsetCheck_iff] at hc
  exact ⟨cells.head!.1, Finset.Subset.antisymm hc.1 hc.2⟩

set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
theorem vertical_catalog_checked :
    (List.range 5320).all (fun i => verticalListCheck ((Generated.levels 6).lookup i).cells) = true := by
  decide +kernel

theorem rooted_oneColumn {s : Finset Cell} (hs : Connected s) (hr : origin ∈ s)
    (hc : s.card = 7) (hcol : ∀ p ∈ s, p.2 = 0) :
    ∃ base, s = verticalSeven base := by
  obtain ⟨i,hi,he⟩ := Generated.rooted_type_exists hs hr hc
  have ht := List.all_eq_true.mp vertical_catalog_checked i (List.mem_range.mpr hi)
  have ht' := verticalListCheck_sound ((Generated.levels 6).lookup i).cells ht
  change ((Generated.levels 6).lookup i).cells.toFinset = s at he
  simpa only [he] using ht' (by simpa only [he] using hcol)

theorem translate_verticalSeven (base row : Int) :
    translate (row,0) (verticalSeven base) = verticalSeven (base+row) := by
  ext p
  simp only [translate, Finset.mem_image]
  constructor
  · rintro ⟨q,hq,rfl⟩
    rw [mem_verticalSeven] at hq ⊢
    simp only [shiftCell]
    omega
  · intro hp
    refine ⟨(p.1-row,p.2),?_,?_⟩
    · rw [mem_verticalSeven] at hp ⊢
      simp only
      omega
    · ext <;> simp [shiftCell]

theorem oneColumn_shape {s : Finset Cell} (hs : Connected s) (hc : s.card = 7)
    (hcol : ∀ p ∈ s, p.2 = 0) : ∃ base, s = verticalSeven base := by
  obtain ⟨p,hp⟩ := hs.1
  have hpcol := hcol p hp
  have hr : origin ∈ translate (negCell p) s := by
    exact Finset.mem_image.mpr ⟨p,hp,by simp [origin, shiftCell, negCell]⟩
  have hcol' : ∀ q ∈ translate (negCell p) s, q.2 = 0 := by
    intro q hq
    obtain ⟨r,hr,rfl⟩ := Finset.mem_image.mp hq
    simp [shiftCell, negCell, hpcol, hcol r hr]
  obtain ⟨base,hbase⟩ := rooted_oneColumn (connected_translate hs _) hr (by simpa using hc) hcol'
  refine ⟨base+p.1,?_⟩
  have he := congrArg (translate p) hbase
  rw [translate_cancel_neg] at he
  have heqp : p = (p.1,0) := by ext <;> simp [hpcol]
  rw [heqp, translate_verticalSeven] at he
  exact he

theorem HeptominoTiling.vertical_tile {h : Nat} (t : HeptominoTiling h 1)
    {s : Finset Cell} (hs : s ∈ t.tiles) : ∃ base, s = verticalSeven base := by
  apply oneColumn_shape (t.connected s hs) (t.size s hs)
  intro p hp
  have := (mem_rectangle h 1 p).mp (t.tile_subset hs hp)
  omega

noncomputable def HeptominoTiling.prefix {h : Nat} (t : HeptominoTiling h 1)
    (n : Nat) (hn : n ≤ h)
    (hcut : ∀ s ∈ t.tiles,
      (∀ p ∈ s, p.1 < n) ∨ (∀ p ∈ s, (n : Int) ≤ p.1)) : HeptominoTiling n 1 := by
  classical
  refine {
    tiles := t.tiles.filter (fun s => ∀ p ∈ s, p.1 < n)
    connected := ?_
    size := ?_
    disjoint := ?_
    covers := ?_ }
  · intro s hs
    exact t.connected s (Finset.mem_filter.mp hs).1
  · intro s hs
    exact t.size s (Finset.mem_filter.mp hs).1
  · intro s hs r hr hsr
    exact t.disjoint (Finset.mem_filter.mp hs).1 (Finset.mem_filter.mp hr).1 hsr
  · ext p
    constructor
    · intro hp
      obtain ⟨s,hs,hp⟩ := Finset.mem_biUnion.mp hp
      obtain ⟨hs,hsn⟩ := Finset.mem_filter.mp hs
      have hb := (mem_rectangle h 1 p).mp (t.tile_subset hs hp)
      have hr := hsn p hp
      rw [mem_rectangle]
      omega
    · intro hp
      have hpb := (mem_rectangle n 1 p).mp hp
      have hp' : p ∈ rectangle h 1 := by rw [mem_rectangle]; omega
      obtain ⟨s,hs,hps⟩ := t.tile_exists hp'
      have hsbelow : ∀ q ∈ s, q.1 < n := by
        rcases hcut s hs with hb | ha
        · exact hb
        · have := ha p hps
          omega
      exact Finset.mem_biUnion.mpr ⟨s,Finset.mem_filter.mpr ⟨hs,hsbelow⟩,hps⟩

theorem HeptominoTiling.vertical_base_divisible {h : Nat} (t : HeptominoTiling h 1)
    {s : Finset Cell} (hs : s ∈ t.tiles) (base : Int) (he : s = verticalSeven base) :
    ∃ n : Nat, (n : Int) = base ∧ 7 ∣ n := by
  have hp : (base,0) ∈ s := by rw [he,mem_verticalSeven]; simp
  have hb := (mem_rectangle h 1 (base,0)).mp (t.tile_subset hs hp)
  let n := base.toNat
  have hnbase : (n : Int) = base := Int.toNat_of_nonneg hb.1
  have hnh : n ≤ h := by omega
  have hcut : ∀ r ∈ t.tiles,
      (∀ p ∈ r, p.1 < n) ∨ (∀ p ∈ r, (n : Int) ≤ p.1) := by
    intro r hr
    by_cases hrs : r = s
    · right
      intro p hp
      rw [hrs,he,mem_verticalSeven] at hp
      omega
    obtain ⟨a,ha⟩ := t.vertical_tile hr
    by_cases hlo : a + 7 ≤ base
    · left
      intro p hp
      rw [ha,mem_verticalSeven] at hp
      omega
    · right
      have hbase : base < a := by
        by_contra hnot
        have hpr : (base,0) ∈ r := by
          rw [ha,mem_verticalSeven]
          exact ⟨rfl, by omega, by omega⟩
        exact (Finset.disjoint_left.mp (t.disjoint hr hs hrs)) hpr hp
      intro p hp
      rw [ha,mem_verticalSeven] at hp
      omega
  refine ⟨n,hnbase,?_⟩
  simpa using (t.prefix n hnh hcut).seven_dvd_area

theorem HeptominoTiling.one_column_subset {h : Nat} (t u : HeptominoTiling h 1) :
    t.tiles ⊆ u.tiles := by
  intro s hs
  obtain ⟨a,ha⟩ := t.vertical_tile hs
  obtain ⟨na,hna,hna7⟩ := t.vertical_base_divisible hs a ha
  have hp : (a,0) ∈ s := by rw [ha,mem_verticalSeven]; simp
  obtain ⟨r,hr,hpr⟩ := u.tile_exists (t.tile_subset hs hp)
  obtain ⟨b,hb⟩ := u.vertical_tile hr
  obtain ⟨nb,hnb,hnb7⟩ := u.vertical_base_divisible hr b hb
  have hrange := (mem_verticalSeven b (a,0)).mp (hb ▸ hpr)
  have hab : a = b := by
    obtain ⟨ka,hka⟩ := hna7
    obtain ⟨kb,hkb⟩ := hnb7
    rw [hka] at hna
    rw [hkb] at hnb
    push_cast at hna hnb
    omega
  have hsr : s = r := by rw [ha,hb,hab]
  exact hsr ▸ hr

/-- A one-cell-wide board has only its consecutive interval partition. -/
theorem HeptominoTiling.one_column_unique {h : Nat} (t u : HeptominoTiling h 1) :
    t.tiles = u.tiles :=
  Finset.Subset.antisymm (t.one_column_subset u) (u.one_column_subset t)

theorem HeptominoTiling.one_row_unique {w : Nat} (t u : HeptominoTiling 1 w) :
    t.tiles = u.tiles := by
  have he := (t.map transposeIso w 1 (transpose_rectangle 1 w)).one_column_unique
    (u.map transposeIso w 1 (transpose_rectangle 1 w))
  apply Finset.image_injective (Finset.image_injective transposeIso.equiv.injective)
  exact he

theorem HeptominoTiling.zero_area_unique {h w : Nat} (hz : h * w = 0)
    (t u : HeptominoTiling h w) : t.tiles = u.tiles := by
  have ht := t.area
  have hu := u.area
  have htc : t.tiles.card = 0 := by omega
  have huc : u.tiles.card = 0 := by omega
  rw [Finset.card_eq_zero.mp htc,Finset.card_eq_zero.mp huc]

/-- The paper excludes boards with a unique tiling as degenerate. -/
def HeptominoTiling.Nondegenerate {h w : Nat} (t : HeptominoTiling h w) : Prop :=
  ∃ u : HeptominoTiling h w, u.tiles ≠ t.tiles

theorem HeptominoTiling.nondegenerate_dimensions {h w : Nat}
    (t : HeptominoTiling h w) (hn : t.Nondegenerate) : 2 ≤ h ∧ 2 ≤ w := by
  obtain ⟨u,hu⟩ := hn
  constructor
  · by_contra hh
    have hh' : h = 0 ∨ h = 1 := by omega
    rcases hh' with rfl | rfl
    · exact hu (u.zero_area_unique (by simp) t)
    · exact hu (u.one_row_unique t)
  · by_contra hw
    have hw' : w = 0 ∨ w = 1 := by omega
    rcases hw' with rfl | rfl
    · exact hu (u.zero_area_unique (by simp) t)
    · exact hu (u.one_column_unique t)

theorem no_locked_nondegenerate_rectangle_of_obstructions
    (obstructions : LocalObstructions) {h w : Nat} (t : HeptominoTiling h w)
    (hn : t.Nondegenerate) : ¬ t.Locked := by
  obtain ⟨hh,hw⟩ := t.nondegenerate_dimensions hn
  exact no_locked_rectangle_of_obstructions obstructions hh hw t

end LockedHeptomino

import LockedHeptomino.Geometry

/-!
# A kernel-checkable certificate for a complete shape list

The external generator supplies lookup indices for every one-cell growth step.
Every target is checked against the actual cell sets.  A balanced lookup tree
keeps those checks logarithmic in the number of shapes even in kernel reduction.
No correctness property of the external generator is assumed.
-/

namespace LockedHeptomino

set_option maxRecDepth 4096

/-- A balanced tree with explicitly supplied branch split points.  Soundness
does not assume these split points describe a balanced or correctly sized tree. -/
inductive LookupTree (α : Type)
  | leaf (value : α)
  | branch (split : Nat) (left right : LookupTree α)
  deriving Inhabited

namespace LookupTree

def lookup {α : Type} : LookupTree α → Nat → α
  | .leaf value, _ => value
  | .branch split left right, i =>
      if i < split then lookup left i else lookup right (i - split)

def all {α : Type} (test : α → Bool) : LookupTree α → Bool
  | .leaf value => test value
  | .branch _ left right => all test left && all test right

theorem all_branch {α : Type} {test : α → Bool} {split : Nat}
    {left right : LookupTree α} (hl : all test left = true) (hr : all test right = true) :
    all test (.branch split left right) = true := by
  change (all test left && all test right) = true
  rw [hl, hr]
  rfl

theorem all_lookup {α : Type} {test : α → Bool} {tree : LookupTree α}
    (h : tree.all test = true) (i : Nat) : test (tree.lookup i) = true := by
  induction tree generalizing i with
  | leaf value => exact h
  | branch split left right ihl ihr =>
      simp only [all, Bool.and_eq_true] at h
      simp only [lookup]
      split
      · exact ihl h.1 _
      · exact ihr h.2 _

end LookupTree

structure ShapeEntry where
  cells : List Cell
  /-- One target index per directed neighbor, in `neighborCandidates` order.
  Entries for neighbors already in the source shape are ignored. -/
  targets : List Nat
  deriving Inhabited

def neighborList (p : Cell) : List Cell :=
  [(p.1 + 1, p.2), (p.1 - 1, p.2), (p.1, p.2 + 1), (p.1, p.2 - 1)]

theorem mem_neighborList_iff {p q : Cell} : q ∈ neighborList p ↔ Adjacent p q := by
  simp [neighborList, adjacent_iff]

def neighborCandidates (cells : List Cell) : List Cell := cells.flatMap neighborList

def checkGrowthSteps (next : Nat → Finset Cell) (bound : Nat) (source : Finset Cell) :
    List Cell → List Nat → Bool
  | [], [] => true
  | q :: qs, j :: js =>
      (decide (q ∈ source) ||
        (decide (j < bound) && decide (insert q source = next j))) &&
      checkGrowthSteps next bound source qs js
  | _, _ => false

theorem checkGrowthSteps_sound {next : Nat → Finset Cell} {bound : Nat}
    {source : Finset Cell} {qs : List Cell} {js : List Nat}
    (h : checkGrowthSteps next bound source qs js = true)
    {q : Cell} (hq : q ∈ qs) (hqnot : q ∉ source) :
    ∃ j < bound, next j = insert q source := by
  induction qs generalizing js with
  | nil => simp at hq
  | cons p ps ih =>
      cases js with
      | nil => simp [checkGrowthSteps] at h
      | cons j js =>
          simp only [checkGrowthSteps, Bool.and_eq_true] at h
          rcases List.mem_cons.mp hq with heq | hrest
          · subst p
            have hhead := h.1
            simp only [hqnot, decide_false, Bool.false_or, Bool.and_eq_true,
              decide_eq_true_eq] at hhead
            exact ⟨j, hhead.1, hhead.2.symm⟩
          · exact ih h.2 hrest

def checkGrowth (next : Nat → Finset Cell) (bound : Nat) (entry : ShapeEntry) : Bool :=
  checkGrowthSteps next bound entry.cells.toFinset
    (neighborCandidates entry.cells) entry.targets

theorem checkGrowth_sound {next : Nat → Finset Cell} {bound : Nat} {entry : ShapeEntry}
    (h : checkGrowth next bound entry = true) {p q : Cell}
    (hp : p ∈ entry.cells.toFinset) (hpq : Adjacent p q)
    (hqnot : q ∉ entry.cells.toFinset) :
    ∃ j < bound, next j = insert q entry.cells.toFinset := by
  apply checkGrowthSteps_sound h _ hqnot
  apply List.mem_flatMap.mpr
  exact ⟨p, List.mem_toFinset.mp hp, mem_neighborList_iff.mpr hpq⟩

def shapeAt (levels : Nat → LookupTree ShapeEntry) (level index : Nat) : Finset Cell :=
  ((levels level).lookup index).cells.toFinset

/-- Checking all six levels of growth proves the supplied heptomino list
contains every possible rooted heptomino, whether or not it contains extras. -/
theorem enumeration_complete (levels : Nat → LookupTree ShapeEntry) (bounds : Nat → Nat)
    (hbase : ∃ i < bounds 0, shapeAt levels 0 i = {origin})
    (hsteps : ∀ n < 6,
      (levels n).all (checkGrowth (shapeAt levels (n + 1)) (bounds (n + 1))) = true)
    {s : Finset Cell} (hs : Connected s) (hroot : origin ∈ s) (hcard : s.card = 7) :
    ∃ i < bounds 6, shapeAt levels 6 i = s := by
  have hmem := rootedHeptominoes_complete hs hroot hcard
  have hall : ∀ n s, s ∈ rootedShapes n →
      n ≤ 6 → ∃ i < bounds n, shapeAt levels n i = s := by
    intro n s hn
    apply rootedShapes_induction (P := fun n s =>
      n ≤ 6 → ∃ i < bounds n, shapeAt levels n i = s) _ _ hn
    · intro _
      exact hbase
    · intro k t ih p hp q hpq hqnot hk
      obtain ⟨i, hi, hit⟩ := ih (by omega)
      have hcheck := LookupTree.all_lookup (hsteps k (by omega)) i
      have hip : p ∈ ((levels k).lookup i).cells.toFinset := by
        change p ∈ shapeAt levels k i
        rw [hit]
        exact hp
      have hiq : q ∉ ((levels k).lookup i).cells.toFinset := by
        change q ∉ shapeAt levels k i
        rw [hit]
        exact hqnot
      obtain ⟨j, hj, hjshape⟩ := checkGrowth_sound hcheck
        hip hpq hiq
      change shapeAt levels (k + 1) j = insert q (shapeAt levels k i) at hjshape
      exact ⟨j, hj, by simpa only [hit] using hjshape⟩
  exact hall 6 s hmem (by omega)

end LockedHeptomino
